import prisma from "@/lib/prisma";
import { SubscriptionPlan, SubscriptionStatus } from "@prisma/client";

export async function getUserSubscription(userId: string) {
  try {
    const subscription = await prisma.subscription.findUnique({
      where: {
        userId,
      },
    });

    if (!subscription) {
      // Create a free subscription for new users
      return prisma.subscription.create({
        data: {
          userId,
          plan: SubscriptionPlan.FREE,
          status: SubscriptionStatus.ACTIVE,
        },
      });
    }

    // Check if subscription has expired
    if (
      subscription.endDate && 
      subscription.endDate < new Date() && 
      subscription.status === SubscriptionStatus.ACTIVE
    ) {
      return prisma.subscription.update({
        where: { id: subscription.id },
        data: { status: SubscriptionStatus.EXPIRED },
      });
    }

    return subscription;
  } catch (error) {
    console.error("Error getting user subscription:", error);
    throw error;
  }
}

export async function isUserPremium(userId: string) {
  try {
    const subscription = await getUserSubscription(userId);
    return (
      subscription.plan === SubscriptionPlan.PREMIUM &&
      subscription.status === SubscriptionStatus.ACTIVE
    );
  } catch (error) {
    console.error("Error checking premium status:", error);
    return false;
  }
}

export async function hasUserPurchasedPack(userId: string, packId: string) {
  try {
    const purchase = await prisma.purchase.findFirst({
      where: {
        userId,
        packId,
        status: "COMPLETED",
      },
    });
    
    return !!purchase;
  } catch (error) {
    console.error("Error checking pack purchase:", error);
    return false;
  }
}