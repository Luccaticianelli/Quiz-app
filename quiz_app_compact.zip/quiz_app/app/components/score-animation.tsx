"use client";

import { useEffect, useState } from "react";
import { motion } from "framer-motion";

interface ScoreAnimationProps {
  score: number;
  duration?: number;
}

const ScoreAnimation = ({ score, duration = 2000 }: ScoreAnimationProps) => {
  const [displayScore, setDisplayScore] = useState(0);

  useEffect(() => {
    let startTime: number;
    let animationFrame: number;

    const animate = (timestamp: number) => {
      if (!startTime) startTime = timestamp;
      const progress = timestamp - startTime;
      const percentage = Math.min(progress / duration, 1);
      
      setDisplayScore(Math.floor(score * percentage));

      if (progress < duration) {
        animationFrame = requestAnimationFrame(animate);
      } else {
        setDisplayScore(score);
      }
    };

    animationFrame = requestAnimationFrame(animate);

    return () => {
      cancelAnimationFrame(animationFrame);
    };
  }, [score, duration]);

  return (
    <motion.div
      initial={{ scale: 0.8, opacity: 0 }}
      animate={{ scale: 1, opacity: 1 }}
      transition={{ duration: 0.5 }}
      className="text-4xl font-bold text-primary"
    >
      {displayScore}
    </motion.div>
  );
};

export default ScoreAnimation;