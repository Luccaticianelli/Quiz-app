"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import Image from "next/image";
import { motion } from "framer-motion";
import { ShoppingCart, Check, Loader2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useToast } from "@/components/ui/use-toast";
import { cn } from "@/lib/utils";

interface QuestionPackCardProps {
  id: string;
  name: string;
  description: string;
  price: number;
  imageUrl?: string;
  theme: string;
  isPurchased: boolean;
  userId?: string;
}

export default function QuestionPackCard({
  id,
  name,
  description,
  price,
  imageUrl,
  theme,
  isPurchased,
  userId,
}: QuestionPackCardProps) {
  const [isLoading, setIsLoading] = useState(false);
  const router = useRouter();
  const { toast } = useToast();

  const handlePurchase = async () => {
    if (!userId) {
      router.push("/auth/login?callbackUrl=/store");
      return;
    }

    setIsLoading(true);

    try {
      const response = await fetch("/api/store/create-checkout", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          packId: id,
        }),
      });

      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.error || "Erro ao processar compra");
      }

      if (data.url) {
        window.location.href = data.url;
      }
    } catch (error: any) {
      console.error("Purchase error:", error);
      toast({
        title: "Erro ao processar compra",
        description: error.message || "Tente novamente mais tarde.",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
      className="flex flex-col overflow-hidden rounded-xl border bg-card shadow-lg"
    >
      <div className="relative h-48 w-full overflow-hidden">
        <Image
          src={
            imageUrl ||
            "https://images.unsplash.com/photo-1606326608606-aa0b62935f2b?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=2070&q=80"
          }
          alt={name}
          fill
          className="object-cover transition-transform duration-300 hover:scale-105"
        />
        <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/70 to-transparent p-4">
          <div className="inline-flex rounded-full bg-primary/20 px-2 py-1 text-xs font-medium text-primary backdrop-blur-sm">
            {theme}
          </div>
        </div>
      </div>

      <div className="flex flex-1 flex-col p-4">
        <h3 className="mb-2 text-xl font-bold">{name}</h3>
        <p className="mb-4 flex-1 text-sm text-muted-foreground">{description}</p>

        <div className="mt-auto flex items-center justify-between">
          <div className="text-lg font-bold">R${price.toFixed(2)}</div>
          <Button
            onClick={handlePurchase}
            disabled={isLoading || isPurchased}
            variant={isPurchased ? "outline" : "gradient"}
            size="sm"
          >
            {isLoading ? (
              <Loader2 className="mr-2 h-4 w-4 animate-spin" />
            ) : isPurchased ? (
              <>
                <Check className="mr-2 h-4 w-4" />
                Adquirido
              </>
            ) : (
              <>
                <ShoppingCart className="mr-2 h-4 w-4" />
                Comprar
              </>
            )}
          </Button>
        </div>
      </div>
    </motion.div>
  );
}