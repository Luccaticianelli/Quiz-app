import { NextResponse } from "next/server";
import { getServerSession } from "next-auth";
import prisma from "@/lib/prisma";
import { authOptions } from "@/lib/auth";

export const dynamic = "force-dynamic";

export async function GET(request: Request) {
  try {
    const session = await getServerSession(authOptions);

    if (!session?.user?.id || session.user.role !== "ADMIN") {
      return NextResponse.json(
        { error: "Não autorizado" },
        { status: 401 }
      );
    }

    const { searchParams } = new URL(request.url);
    const theme = searchParams.get("theme");
    const type = searchParams.get("type");
    const difficulty = searchParams.get("difficulty");
    const isPremium = searchParams.get("isPremium");
    const packId = searchParams.get("packId");
    
    const questions = await prisma.question.findMany({
      where: {
        ...(theme ? { theme } : {}),
        ...(type ? { type } : {}),
        ...(difficulty ? { difficulty } : {}),
        ...(isPremium ? { isPremium: isPremium === "true" } : {}),
        ...(packId ? { packId } : {}),
      },
      orderBy: {
        createdAt: "desc",
      },
    });
    
    return NextResponse.json({ questions });
  } catch (error) {
    console.error("Error fetching questions:", error);
    return NextResponse.json(
      { error: "Erro ao buscar perguntas" },
      { status: 500 }
    );
  }
}

export async function POST(request: Request) {
  try {
    const session = await getServerSession(authOptions);

    if (!session?.user?.id || session.user.role !== "ADMIN") {
      return NextResponse.json(
        { error: "Não autorizado" },
        { status: 401 }
      );
    }

    const body = await request.json();
    const { question, theme, type, options, correctAnswer, difficulty, isPremium, packId } = body;

    if (!question || !theme || !type || !options || !correctAnswer || !difficulty) {
      return NextResponse.json(
        { error: "Dados incompletos" },
        { status: 400 }
      );
    }

    const newQuestion = await prisma.question.create({
      data: {
        question,
        theme,
        type,
        options,
        correctAnswer,
        difficulty,
        isPremium: isPremium || false,
        packId: packId || null,
      },
    });
    
    return NextResponse.json({ question: newQuestion });
  } catch (error) {
    console.error("Error creating question:", error);
    return NextResponse.json(
      { error: "Erro ao criar pergunta" },
      { status: 500 }
    );
  }
}