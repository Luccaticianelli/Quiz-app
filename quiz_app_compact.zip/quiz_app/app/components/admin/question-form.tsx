"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Loader2, Plus, Trash2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import { useToast } from "@/components/ui/use-toast";
import { themes } from "@/lib/utils";

const formSchema = z.object({
  question: z.string().min(5, "A pergunta deve ter pelo menos 5 caracteres"),
  theme: z.string().min(1, "Selecione um tema"),
  type: z.string().min(1, "Selecione um tipo"),
  difficulty: z.string().min(1, "Selecione uma dificuldade"),
  options: z.array(z.string().min(1, "A opção não pode estar vazia")).min(2, "Adicione pelo menos 2 opções"),
  correctAnswer: z.string().min(1, "Selecione a resposta correta"),
  isPremium: z.boolean().default(false),
  packId: z.string().optional(),
});

type FormValues = z.infer<typeof formSchema>;

interface QuestionFormProps {
  questionPacks?: { id: string; name: string }[];
  initialData?: any;
}

export default function QuestionForm({ questionPacks = [], initialData }: QuestionFormProps) {
  const [isLoading, setIsLoading] = useState(false);
  const router = useRouter();
  const { toast } = useToast();
  const isEditing = !!initialData;

  const form = useForm<FormValues>({
    resolver: zodResolver(formSchema),
    defaultValues: initialData || {
      question: "",
      theme: "",
      type: "",
      difficulty: "",
      options: ["", ""],
      correctAnswer: "",
      isPremium: false,
      packId: "",
    },
  });

  const watchType = form.watch("type");
  const watchOptions = form.watch("options");

  const onSubmit = async (values: FormValues) => {
    setIsLoading(true);

    try {
      const url = isEditing
        ? `/api/admin/questions/${initialData.id}`
        : "/api/admin/questions";
      
      const method = isEditing ? "PATCH" : "POST";

      const response = await fetch(url, {
        method,
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(values),
      });

      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.error || "Erro ao salvar pergunta");
      }

      toast({
        title: isEditing ? "Pergunta atualizada!" : "Pergunta criada!",
        description: isEditing
          ? "A pergunta foi atualizada com sucesso."
          : "A pergunta foi adicionada ao banco de dados.",
      });

      router.push("/admin/questions");
      router.refresh();
    } catch (error: any) {
      console.error("Question form error:", error);
      toast({
        title: "Erro",
        description: error.message || "Ocorreu um erro ao salvar a pergunta.",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  const addOption = () => {
    const currentOptions = form.getValues("options");
    form.setValue("options", [...currentOptions, ""]);
  };

  const removeOption = (index: number) => {
    const currentOptions = form.getValues("options");
    if (currentOptions.length <= 2) return;
    
    const newOptions = currentOptions.filter((_, i) => i !== index);
    form.setValue("options", newOptions);
    
    // If removing the correct answer, reset it
    const correctAnswer = form.getValues("correctAnswer");
    if (correctAnswer === currentOptions[index]) {
      form.setValue("correctAnswer", "");
    }
  };

  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
        <FormField
          control={form.control}
          name="question"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Pergunta</FormLabel>
              <FormControl>
                <Textarea
                  placeholder="Digite a pergunta..."
                  className="min-h-[100px]"
                  {...field}
                />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />

        <div className="grid gap-6 md:grid-cols-2">
          <FormField
            control={form.control}
            name="theme"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Tema</FormLabel>
                <Select
                  onValueChange={field.onChange}
                  defaultValue={field.value}
                  disabled={isLoading}
                >
                  <FormControl>
                    <SelectTrigger>
                      <SelectValue placeholder="Selecione um tema" />
                    </SelectTrigger>
                  </FormControl>
                  <SelectContent>
                    {themes.map((theme) => (
                      <SelectItem key={theme.id} value={theme.name}>
                        {theme.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                <FormMessage />
              </FormItem>
            )}
          />

          <FormField
            control={form.control}
            name="type"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Tipo</FormLabel>
                <Select
                  onValueChange={field.onChange}
                  defaultValue={field.value}
                  disabled={isLoading}
                >
                  <FormControl>
                    <SelectTrigger>
                      <SelectValue placeholder="Selecione um tipo" />
                    </SelectTrigger>
                  </FormControl>
                  <SelectContent>
                    <SelectItem value="multiple_choice">Múltipla Escolha</SelectItem>
                    <SelectItem value="true_false">Verdadeiro ou Falso</SelectItem>
                  </SelectContent>
                </Select>
                <FormMessage />
              </FormItem>
            )}
          />

          <FormField
            control={form.control}
            name="difficulty"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Dificuldade</FormLabel>
                <Select
                  onValueChange={field.onChange}
                  defaultValue={field.value}
                  disabled={isLoading}
                >
                  <FormControl>
                    <SelectTrigger>
                      <SelectValue placeholder="Selecione a dificuldade" />
                    </SelectTrigger>
                  </FormControl>
                  <SelectContent>
                    <SelectItem value="easy">Fácil</SelectItem>
                    <SelectItem value="medium">Médio</SelectItem>
                    <SelectItem value="hard">Difícil</SelectItem>
                  </SelectContent>
                </Select>
                <FormMessage />
              </FormItem>
            )}
          />

          <FormField
            control={form.control}
            name="packId"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Pacote de Perguntas (Opcional)</FormLabel>
                <Select
                  onValueChange={field.onChange}
                  defaultValue={field.value}
                  disabled={isLoading}
                >
                  <FormControl>
                    <SelectTrigger>
                      <SelectValue placeholder="Selecione um pacote" />
                    </SelectTrigger>
                  </FormControl>
                  <SelectContent>
                    <SelectItem value="">Nenhum</SelectItem>
                    {questionPacks.map((pack) => (
                      <SelectItem key={pack.id} value={pack.id}>
                        {pack.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                <FormMessage />
              </FormItem>
            )}
          />
        </div>

        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <FormLabel>Opções</FormLabel>
            {watchType === "multiple_choice" && (
              <Button
                type="button"
                variant="outline"
                size="sm"
                onClick={addOption}
                disabled={watchOptions.length >= 5}
              >
                <Plus className="mr-2 h-4 w-4" />
                Adicionar Opção
              </Button>
            )}
          </div>

          {watchType === "true_false" ? (
            <div className="grid gap-4 md:grid-cols-2">
              {["Verdadeiro", "Falso"].map((option, index) => (
                <div key={index} className="relative">
                  <Input value={option} disabled className="pr-10" />
                </div>
              ))}
            </div>
          ) : (
            <div className="space-y-3">
              {watchOptions.map((_, index) => (
                <FormField
                  key={index}
                  control={form.control}
                  name={`options.${index}`}
                  render={({ field }) => (
                    <FormItem>
                      <FormControl>
                        <div className="relative">
                          <Input
                            {...field}
                            placeholder={`Opção ${index + 1}`}
                            disabled={isLoading}
                            className="pr-10"
                          />
                          {index >= 2 && (
                            <Button
                              type="button"
                              variant="ghost"
                              size="sm"
                              className="absolute right-1 top-1 h-8 w-8 p-0"
                              onClick={() => removeOption(index)}
                            >
                              <Trash2 className="h-4 w-4 text-muted-foreground" />
                            </Button>
                          )}
                        </div>
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              ))}
            </div>
          )}
        </div>

        <FormField
          control={form.control}
          name="correctAnswer"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Resposta Correta</FormLabel>
              <Select
                onValueChange={field.onChange}
                defaultValue={field.value}
                disabled={isLoading}
              >
                <FormControl>
                  <SelectTrigger>
                    <SelectValue placeholder="Selecione a resposta correta" />
                  </SelectTrigger>
                </FormControl>
                <SelectContent>
                  {watchType === "true_false" ? (
                    ["Verdadeiro", "Falso"].map((option) => (
                      <SelectItem key={option} value={option}>
                        {option}
                      </SelectItem>
                    ))
                  ) : (
                    watchOptions.map((option, index) => (
                      <SelectItem key={index} value={option} disabled={!option.trim()}>
                        {option || `Opção ${index + 1}`}
                      </SelectItem>
                    ))
                  )}
                </SelectContent>
              </Select>
              <FormMessage />
            </FormItem>
          )}
        />

        <FormField
          control={form.control}
          name="isPremium"
          render={({ field }) => (
            <FormItem className="flex flex-row items-center justify-between rounded-lg border p-4">
              <div className="space-y-0.5">
                <FormLabel className="text-base">Conteúdo Premium</FormLabel>
                <p className="text-sm text-muted-foreground">
                  Marque esta opção para disponibilizar apenas para assinantes premium
                </p>
              </div>
              <FormControl>
                <Switch
                  checked={field.value}
                  onCheckedChange={field.onChange}
                  disabled={isLoading}
                />
              </FormControl>
            </FormItem>
          )}
        />

        <Button type="submit" disabled={isLoading} className="w-full">
          {isLoading && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
          {isEditing ? "Atualizar Pergunta" : "Criar Pergunta"}
        </Button>
      </form>
    </Form>
  );
}