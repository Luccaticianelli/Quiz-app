import { NextResponse } from "next/server";
import { getServerSession } from "next-auth";
import prisma from "@/lib/prisma";
import { authOptions } from "@/lib/auth";

export const dynamic = "force-dynamic";

export async function GET(request: Request) {
  try {
    const session = await getServerSession(authOptions);

    if (!session?.user?.id || session.user.role !== "ADMIN") {
      return NextResponse.json(
        { error: "Não autorizado" },
        { status: 401 }
      );
    }

    const { searchParams } = new URL(request.url);
    const theme = searchParams.get("theme");
    const isActive = searchParams.get("isActive");
    
    const packs = await prisma.questionPack.findMany({
      where: {
        ...(theme ? { theme } : {}),
        ...(isActive ? { isActive: isActive === "true" } : {}),
      },
      orderBy: {
        createdAt: "desc",
      },
      include: {
        _count: {
          select: {
            questions: true,
            purchases: true,
          },
        },
      },
    });
    
    return NextResponse.json({ packs });
  } catch (error) {
    console.error("Error fetching question packs:", error);
    return NextResponse.json(
      { error: "Erro ao buscar pacotes de perguntas" },
      { status: 500 }
    );
  }
}

export async function POST(request: Request) {
  try {
    const session = await getServerSession(authOptions);

    if (!session?.user?.id || session.user.role !== "ADMIN") {
      return NextResponse.json(
        { error: "Não autorizado" },
        { status: 401 }
      );
    }

    const body = await request.json();
    const { name, description, price, theme, imageUrl, isActive } = body;

    if (!name || !description || price === undefined || !theme) {
      return NextResponse.json(
        { error: "Dados incompletos" },
        { status: 400 }
      );
    }

    const newPack = await prisma.questionPack.create({
      data: {
        name,
        description,
        price,
        theme,
        imageUrl: imageUrl || null,
        isActive: isActive !== undefined ? isActive : true,
      },
    });
    
    return NextResponse.json({ pack: newPack });
  } catch (error) {
    console.error("Error creating question pack:", error);
    return NextResponse.json(
      { error: "Erro ao criar pacote de perguntas" },
      { status: 500 }
    );
  }
}