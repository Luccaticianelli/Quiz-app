"use client";

import { useEffect, useState } from "react";
import { motion } from "framer-motion";
import { Clock } from "lucide-react";
import { Progress } from "@/components/ui/progress";

interface CountdownTimerProps {
  duration: number;
  onTimeout: () => void;
  isPaused: boolean;
}

const CountdownTimer = ({ duration, onTimeout, isPaused }: CountdownTimerProps) => {
  const [timeLeft, setTimeLeft] = useState(duration);
  const [isWarning, setIsWarning] = useState(false);

  useEffect(() => {
    if (isPaused) return;

    const timer = setInterval(() => {
      setTimeLeft((prev) => {
        if (prev <= 1) {
          clearInterval(timer);
          onTimeout();
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(timer);
  }, [duration, onTimeout, isPaused]);

  useEffect(() => {
    if (timeLeft <= 10) {
      setIsWarning(true);
    } else {
      setIsWarning(false);
    }
  }, [timeLeft]);

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins.toString().padStart(2, "0")}:${secs.toString().padStart(2, "0")}`;
  };

  const progressValue = (timeLeft / duration) * 100;

  return (
    <div className="mb-6 flex flex-col gap-2">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2 text-sm font-medium">
          <Clock className="h-4 w-4" />
          <span>Tempo Restante</span>
        </div>
        <motion.div
          animate={isWarning ? { scale: [1, 1.1, 1] } : {}}
          transition={{ repeat: isWarning ? Infinity : 0, duration: 0.5 }}
          className={`text-sm font-bold ${
            isWarning ? "text-red-500" : "text-foreground"
          }`}
        >
          {formatTime(timeLeft)}
        </motion.div>
      </div>
      <Progress
        value={progressValue}
        className={`h-2 ${
          isWarning
            ? "bg-red-200 [&>div]:bg-red-500"
            : "bg-primary/20 [&>div]:bg-primary"
        }`}
      />
    </div>
  );
};

export default CountdownTimer;