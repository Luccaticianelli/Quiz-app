"use client";

import { useState, useEffect } from "react";
import { useRouter, useSearchParams } from "next/navigation";
import Image from "next/image";
import { motion } from "framer-motion";
import { Trophy, Share2, Home, RotateCcw } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import ScoreAnimation from "@/components/score-animation";
import ConfettiExplosion from "@/components/confetti-explosion";
import { themes } from "@/lib/utils";

export default function ResultsPage({ params }: { params: { theme: string } }) {
  const router = useRouter();
  const searchParams = useSearchParams();
  const score = parseInt(searchParams.get("score") || "0");
  const [showConfetti, setShowConfetti] = useState(false);
  const [userName, setUserName] = useState("");
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isSubmitted, setIsSubmitted] = useState(false);

  const theme = themes.find((t) => t.id === params.theme);
  const themeName = theme?.name || params.theme;

  useEffect(() => {
    // Show confetti animation on load
    setShowConfetti(true);
    
    // Hide confetti after 5 seconds
    const timer = setTimeout(() => {
      setShowConfetti(false);
    }, 5000);
    
    return () => clearTimeout(timer);
  }, []);

  const handleSubmitScore = async () => {
    if (!userName.trim()) return;
    
    setIsSubmitting(true);
    
    try {
      // In a real app, this would be an API call to save the score
      // await fetch('/api/scores', {
      //   method: 'POST',
      //   headers: { 'Content-Type': 'application/json' },
      //   body: JSON.stringify({ name: userName, score, theme: themeName }),
      // });
      
      // Simulate API call
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      setIsSubmitted(true);
    } catch (error) {
      console.error("Error submitting score:", error);
    } finally {
      setIsSubmitting(false);
    }
  };

  const getScoreMessage = () => {
    if (score >= 800) return "Incrível! Você é um mestre neste tema!";
    if (score >= 500) return "Muito bom! Você tem um ótimo conhecimento!";
    if (score >= 300) return "Bom trabalho! Continue praticando!";
    return "Continue tentando! A prática leva à perfeição!";
  };

  const handleShare = () => {
    if (navigator.share) {
      navigator.share({
        title: "Minha pontuação no QuizMaster",
        text: `Fiz ${score} pontos no tema ${themeName} no QuizMaster! Tente superar!`,
        url: window.location.href,
      });
    } else {
      // Fallback for browsers that don't support Web Share API
      navigator.clipboard.writeText(
        `Fiz ${score} pontos no tema ${themeName} no QuizMaster! Tente superar! ${window.location.href}`
      );
      alert("Link copiado para a área de transferência!");
    }
  };

  return (
    <div className="container mx-auto flex min-h-[calc(100vh-4rem)] max-w-screen-md items-center justify-center px-4 py-8">
      {showConfetti && <ConfettiExplosion />}
      
      <Card className="w-full max-w-md">
        <CardHeader className={`bg-gradient-to-r ${theme?.color} text-center text-white`}>
          <motion.div
            initial={{ scale: 0 }}
            animate={{ scale: 1 }}
            transition={{ type: "spring", duration: 0.5 }}
            className="mx-auto mb-4 flex h-20 w-20 items-center justify-center rounded-full bg-white/20 backdrop-blur-sm"
          >
            <Trophy className="h-10 w-10" />
          </motion.div>
          <CardTitle className="text-2xl">Resultado do Quiz</CardTitle>
          <p className="text-white/80">{themeName}</p>
        </CardHeader>
        
        <CardContent className="p-6 text-center">
          <div className="mb-6">
            <p className="mb-2 text-sm font-medium text-muted-foreground">Sua pontuação</p>
            <ScoreAnimation score={score} />
            <motion.p
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 2 }}
              className="mt-2 text-muted-foreground"
            >
              {getScoreMessage()}
            </motion.p>
          </div>
          
          {!isSubmitted ? (
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 1 }}
              className="mb-4"
            >
              <p className="mb-2 text-sm font-medium">Salvar sua pontuação no ranking</p>
              <div className="flex gap-2">
                <input
                  type="text"
                  placeholder="Seu nome"
                  value={userName}
                  onChange={(e) => setUserName(e.target.value)}
                  className="flex-1 rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background file:border-0 file:bg-transparent file:text-sm file:font-medium placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50"
                />
                <Button
                  onClick={handleSubmitScore}
                  disabled={!userName.trim() || isSubmitting}
                  variant="gradient"
                >
                  {isSubmitting ? "Salvando..." : "Salvar"}
                </Button>
              </div>
            </motion.div>
          ) : (
            <motion.div
              initial={{ opacity: 0, scale: 0.8 }}
              animate={{ opacity: 1, scale: 1 }}
              className="mb-4 rounded-lg bg-green-500/10 p-3 text-green-600"
            >
              <p>Pontuação salva com sucesso!</p>
            </motion.div>
          )}
          
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 1.5 }}
            className="relative mt-6 h-40 w-full"
          >
            <Image
              src="https://thumbs.dreamstime.com/z/golden-cups-awards-as-achievement-trophy-winners-vector-set-reward-shiny-goblets-victory-symbol-259124273.jpg"
              alt="Achievement"
              fill
              className="object-contain"
            />
          </motion.div>
        </CardContent>
        
        <CardFooter className="flex flex-wrap justify-center gap-2 border-t p-4">
          <Button variant="outline" onClick={() => router.push("/")}>
            <Home className="mr-2 h-4 w-4" />
            Página Inicial
          </Button>
          <Button variant="outline" onClick={() => router.push(`/quiz/${params.theme}`)}>
            <RotateCcw className="mr-2 h-4 w-4" />
            Jogar Novamente
          </Button>
          <Button variant="outline" onClick={handleShare}>
            <Share2 className="mr-2 h-4 w-4" />
            Compartilhar
          </Button>
          <Button variant="gradient" onClick={() => router.push("/ranking")}>
            <Trophy className="mr-2 h-4 w-4" />
            Ver Ranking
          </Button>
        </CardFooter>
      </Card>
    </div>
  );
}