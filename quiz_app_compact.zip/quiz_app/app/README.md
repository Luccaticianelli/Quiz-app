# QuizMaster - Aplicativo de Quiz

QuizMaster é um aplicativo de quiz interativo com perguntas de múltipla escolha e verdadeiro ou falso sobre diversos temas como Artes, Música, Geografia, História do Brasil, História e Esportes.

## Funcionalidades

- Seleção de temas (Artes, Música, Geografia, História do Brasil, História, Esportes)
- Perguntas de múltipla escolha e verdadeiro/falso
- Sistema de pontuação baseado na dificuldade e tempo de resposta
- Ranking de jogadores
- Perfil de usuário com estatísticas
- Design responsivo para web e mobile

## Tecnologias Utilizadas

- Next.js 14
- React 18
- TypeScript
- Tailwind CSS
- Prisma (ORM)
- PostgreSQL
- Framer Motion (animações)
- Chart.js (gráficos)

## Como Executar

1. Clone o repositório:
```bash
git clone <url-do-repositorio>
cd quizmaster
```

2. Instale as dependências:
```bash
npm install
```

3. Configure o banco de dados:
   - Crie um arquivo `.env` na raiz do projeto com a seguinte variável:
   ```
   DATABASE_URL="postgresql://usuario:senha@localhost:5432/quizmaster"
   ```
   - Substitua `usuario`, `senha` e `quizmaster` pelos seus dados de conexão PostgreSQL

4. Execute as migrações do Prisma:
```bash
npx prisma migrate dev --name init
```

5. Inicie o servidor de desenvolvimento:
```bash
npm run dev
```

6. Acesse o aplicativo em `http://localhost:3000`

## Estrutura do Projeto

- `/app`: Páginas e rotas da aplicação
- `/components`: Componentes React reutilizáveis
- `/lib`: Utilitários e configurações
- `/prisma`: Schema do banco de dados
- `/public`: Arquivos estáticos
- `/data`: Dados de perguntas e respostas

## Contribuição

Contribuições são bem-vindas! Sinta-se à vontade para abrir issues ou enviar pull requests.

## Licença

Este projeto está licenciado sob a licença MIT.