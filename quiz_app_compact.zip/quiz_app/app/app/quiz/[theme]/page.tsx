"use client";

import { useState, useEffect } from "react";
import { useRouter } from "next/navigation";
import { motion, AnimatePresence } from "framer-motion";
import { HelpCircle, AlertTriangle } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import CountdownTimer from "@/components/countdown-timer";
import QuizOption from "@/components/quiz-option";
import { shuffleArray, themes } from "@/lib/utils";
import questionsData from "@/data/questions_database.json";

interface Question {
  id: number;
  theme: string;
  type: string;
  question: string;
  options: string[];
  correct_answer: string;
  difficulty: string;
}

export default function QuizPage({ params }: { params: { theme: string } }) {
  const router = useRouter();
  const [questions, setQuestions] = useState<Question[]>([]);
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [selectedOption, setSelectedOption] = useState<string | null>(null);
  const [isAnswerChecked, setIsAnswerChecked] = useState(false);
  const [score, setScore] = useState(0);
  const [timeLeft, setTimeLeft] = useState(30);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const theme = themes.find((t) => t.id === params.theme);
  const themeName = theme?.name || params.theme;

  useEffect(() => {
    try {
      // Filter questions by theme
      const allQuestions = questionsData.questions as unknown as Question[];
      
      if (!Array.isArray(allQuestions)) {
        setError("Formato de dados inválido");
        setIsLoading(false);
        return;
      }
      
      const themeQuestions = allQuestions.filter(
        (q) => q.theme.toLowerCase() === themeName.toLowerCase()
      );
      
      if (themeQuestions.length === 0) {
        setError(`Nenhuma pergunta encontrada para o tema ${themeName}`);
        setIsLoading(false);
        return;
      }
      
      // Shuffle and limit to 10 questions
      const shuffledQuestions = shuffleArray(themeQuestions).slice(0, 10);
      setQuestions(shuffledQuestions);
      setIsLoading(false);
    } catch (err) {
      console.error("Erro ao carregar perguntas:", err);
      setError("Erro ao carregar perguntas. Por favor, tente novamente.");
      setIsLoading(false);
    }
  }, [themeName]);

  const currentQuestion = questions[currentQuestionIndex];

  const handleOptionSelect = (option: string) => {
    if (isAnswerChecked) return;
    setSelectedOption(option);
  };

  const handleCheckAnswer = () => {
    if (!selectedOption || isAnswerChecked) return;
    
    setIsAnswerChecked(true);
    
    if (selectedOption === currentQuestion.correct_answer) {
      // Calculate score based on difficulty and time left
      const difficultyMultiplier = 
        currentQuestion.difficulty === "easy" ? 1 :
        currentQuestion.difficulty === "medium" ? 2 : 3;
      
      const timeBonus = Math.floor(timeLeft / 3);
      const questionScore = 100 * difficultyMultiplier + timeBonus;
      
      setScore(prev => prev + questionScore);
    }
  };

  const handleNextQuestion = () => {
    if (currentQuestionIndex < questions.length - 1) {
      setCurrentQuestionIndex(prev => prev + 1);
      setSelectedOption(null);
      setIsAnswerChecked(false);
      setTimeLeft(30);
    } else {
      // Quiz finished, navigate to results
      router.push(`/quiz/${params.theme}/results?score=${score}`);
    }
  };

  const handleTimeout = () => {
    if (!isAnswerChecked) {
      setIsAnswerChecked(true);
    }
  };

  if (isLoading) {
    return (
      <div className="flex min-h-[calc(100vh-4rem)] items-center justify-center">
        <div className="text-center">
          <div className="mb-4 h-12 w-12 animate-spin rounded-full border-4 border-primary border-t-transparent"></div>
          <p>Carregando perguntas...</p>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="flex min-h-[calc(100vh-4rem)] items-center justify-center p-4">
        <Card className="w-full max-w-md">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-destructive">
              <AlertTriangle className="h-5 w-5" />
              Erro
            </CardTitle>
          </CardHeader>
          <CardContent>
            <p>{error}</p>
          </CardContent>
          <CardFooter>
            <Button onClick={() => router.push("/")} className="w-full">
              Voltar para a página inicial
            </Button>
          </CardFooter>
        </Card>
      </div>
    );
  }

  if (!currentQuestion) {
    return (
      <div className="flex min-h-[calc(100vh-4rem)] items-center justify-center p-4">
        <Card className="w-full max-w-md">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <HelpCircle className="h-5 w-5" />
              Nenhuma pergunta disponível
            </CardTitle>
          </CardHeader>
          <CardContent>
            <p>Não há perguntas disponíveis para este tema no momento.</p>
          </CardContent>
          <CardFooter>
            <Button onClick={() => router.push("/")} className="w-full">
              Voltar para a página inicial
            </Button>
          </CardFooter>
        </Card>
      </div>
    );
  }

  return (
    <div className="container mx-auto max-w-screen-md px-4 py-8">
      <div className="mb-6 flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold">{themeName}</h1>
          <p className="text-sm text-muted-foreground">
            Pergunta {currentQuestionIndex + 1} de {questions.length}
          </p>
        </div>
        <div className="text-right">
          <p className="text-sm text-muted-foreground">Pontuação</p>
          <p className="text-xl font-bold">{score}</p>
        </div>
      </div>

      <Card className="mb-6 overflow-hidden">
        <CardHeader className={`bg-gradient-to-r ${theme?.color} text-white`}>
          <div className="flex items-center gap-2">
            <span className="rounded-md bg-white/20 px-2 py-1 text-xs font-medium uppercase">
              {currentQuestion.difficulty}
            </span>
            <span className="rounded-md bg-white/20 px-2 py-1 text-xs font-medium uppercase">
              {currentQuestion.type === "multiple_choice" ? "Múltipla Escolha" : "Verdadeiro ou Falso"}
            </span>
          </div>
          <CardTitle className="text-xl">{currentQuestion.question}</CardTitle>
        </CardHeader>
        <CardContent className="p-6">
          <CountdownTimer
            duration={30}
            onTimeout={handleTimeout}
            isPaused={isAnswerChecked}
          />

          <div className="space-y-3">
            <AnimatePresence mode="wait">
              {currentQuestion.options.map((option, index) => (
                <QuizOption
                  key={option}
                  option={option}
                  index={index}
                  selected={selectedOption === option}
                  correct={
                    isAnswerChecked
                      ? option === currentQuestion.correct_answer
                        ? true
                        : selectedOption === option
                        ? false
                        : null
                      : null
                  }
                  disabled={isAnswerChecked}
                  onSelect={() => handleOptionSelect(option)}
                />
              ))}
            </AnimatePresence>
          </div>
        </CardContent>
        <CardFooter className="flex justify-between border-t bg-muted/30 p-4">
          <div className="text-sm text-muted-foreground">
            {isAnswerChecked && (
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                className={`font-medium ${
                  selectedOption === currentQuestion.correct_answer
                    ? "text-green-600"
                    : "text-red-600"
                }`}
              >
                {selectedOption === currentQuestion.correct_answer
                  ? "Resposta correta!"
                  : `Resposta incorreta. A resposta correta é: ${currentQuestion.correct_answer}`}
              </motion.div>
            )}
          </div>
          <div>
            {!isAnswerChecked ? (
              <Button
                onClick={handleCheckAnswer}
                disabled={!selectedOption}
                variant="gradient"
              >
                Verificar
              </Button>
            ) : (
              <Button onClick={handleNextQuestion} variant="gradient">
                {currentQuestionIndex < questions.length - 1
                  ? "Próxima Pergunta"
                  : "Ver Resultados"}
              </Button>
            )}
          </div>
        </CardFooter>
      </Card>
    </div>
  );
}