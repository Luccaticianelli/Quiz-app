import { NextResponse } from "next/server";
import prisma from "@/lib/prisma";

export const dynamic = "force-dynamic";

export async function POST(request: Request) {
  try {
    const body = await request.json();
    const { name, score, theme } = body;
    
    if (!name || !score || !theme) {
      return NextResponse.json(
        { error: "Missing required fields" },
        { status: 400 }
      );
    }
    
    // Create a temporary user if not authenticated
    const user = await prisma.user.create({
      data: {
        name,
        email: `temp_${Date.now()}@example.com`, // Temporary email
      },
    });
    
    // Create the score record
    const newScore = await prisma.score.create({
      data: {
        score,
        theme,
        userId: user.id,
      },
    });
    
    return NextResponse.json({ success: true, score: newScore });
  } catch (error) {
    console.error("Error saving score:", error);
    return NextResponse.json(
      { error: "Failed to save score" },
      { status: 500 }
    );
  }
}

export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url);
    const theme = searchParams.get("theme");
    const limit = parseInt(searchParams.get("limit") || "10");
    
    const scores = await prisma.score.findMany({
      where: theme ? { theme } : undefined,
      orderBy: {
        score: "desc",
      },
      take: limit,
      include: {
        user: {
          select: {
            name: true,
          },
        },
      },
    });
    
    return NextResponse.json({ scores });
  } catch (error) {
    console.error("Error fetching scores:", error);
    return NextResponse.json(
      { error: "Failed to fetch scores" },
      { status: 500 }
    );
  }
}