"use client";

import { motion } from "framer-motion";
import { Check, X } from "lucide-react";
import { cn } from "@/lib/utils";

interface QuizOptionProps {
  option: string;
  index: number;
  selected: boolean;
  correct: boolean | null;
  disabled: boolean;
  onSelect: () => void;
}

const QuizOption = ({
  option,
  index,
  selected,
  correct,
  disabled,
  onSelect,
}: QuizOptionProps) => {
  const letters = ["A", "B", "C", "D", "E"];
  const letter = letters[index];

  let optionClass = "option-card";
  if (selected) optionClass += " selected";
  if (correct === true) optionClass += " correct";
  if (correct === false) optionClass += " incorrect";

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.3, delay: index * 0.1 }}
      whileHover={!disabled ? { scale: 1.02 } : {}}
      className={cn(optionClass, "cursor-pointer")}
      onClick={() => !disabled && onSelect()}
    >
      <div className="flex items-center gap-3">
        <div
          className={cn(
            "flex h-8 w-8 items-center justify-center rounded-full text-sm font-medium",
            selected
              ? "bg-primary text-primary-foreground"
              : "bg-muted text-muted-foreground"
          )}
        >
          {letter}
        </div>
        <div className="flex-1">{option}</div>
        {correct === true && (
          <div className="flex h-6 w-6 items-center justify-center rounded-full bg-green-500 text-white">
            <Check className="h-4 w-4" />
          </div>
        )}
        {correct === false && (
          <div className="flex h-6 w-6 items-center justify-center rounded-full bg-red-500 text-white">
            <X className="h-4 w-4" />
          </div>
        )}
      </div>
    </motion.div>
  );
};

export default QuizOption;