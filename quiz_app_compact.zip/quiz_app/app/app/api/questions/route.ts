import { NextResponse } from "next/server";
import prisma from "@/lib/prisma";
import questionsData from "@/data/questions_database.json";

export const dynamic = "force-dynamic";

export async function GET(request: Request) {
  const { searchParams } = new URL(request.url);
  const theme = searchParams.get("theme");
  
  try {
    // Check if we have questions in the database
    const count = await prisma.question.count();
    
    // If no questions, seed the database with the JSON data
    if (count === 0) {
      const questions = questionsData.questions as any[];
      
      if (Array.isArray(questions)) {
        // Batch insert questions
        await prisma.question.createMany({
          data: questions.map(q => ({
            theme: q.theme,
            type: q.type,
            question: q.question,
            options: q.options,
            correctAnswer: q.correct_answer,
            difficulty: q.difficulty
          })),
          skipDuplicates: true,
        });
      }
    }
    
    // Query for questions, optionally filtered by theme
    const questions = await prisma.question.findMany({
      where: theme ? {
        theme: {
          equals: theme,
          mode: 'insensitive'
        }
      } : undefined,
    });
    
    return NextResponse.json({ questions });
  } catch (error) {
    console.error("Error fetching questions:", error);
    return NextResponse.json(
      { error: "Failed to fetch questions" },
      { status: 500 }
    );
  }
}