import { Suspense } from "react";
import Link from "next/link";
import Image from "next/image";
import { ArrowRight, Brain, Trophy } from "lucide-react";
import { themes } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import QuizCardStatic from "@/components/quiz-card-static";

export default function Home() {
  return (
    <div className="flex min-h-screen flex-col">
      {/* Hero Section */}
      <section className="relative flex min-h-[70vh] items-center justify-center overflow-hidden bg-gradient-to-b from-primary/20 to-background px-4 py-16">
        <div className="absolute inset-0 z-0">
          <div className="absolute inset-0 bg-gradient-to-b from-transparent to-background" />
          <Image
            src="https://static.vecteezy.com/system/resources/previews/007/653/575/original/seamless-pattern-background-with-bright-sign-question-marks-on-white-backdrop-feedback-brainstorm-opinion-reaction-questionnaire-learning-concept-business-office-wallpaper-vector.jpg"
            alt="Quiz background"
            fill
            className="object-cover opacity-20"
            priority
          />
        </div>
        <div className="container relative z-10 mx-auto max-w-screen-xl">
          <div className="grid gap-8 md:grid-cols-2 md:gap-12">
            <div className="flex flex-col justify-center">
              <div>
                <h1 className="mb-4 text-4xl font-extrabold tracking-tight md:text-5xl lg:text-6xl">
                  Teste seus conhecimentos com o{" "}
                  <span className="bg-gradient-to-r from-primary to-purple-600 bg-clip-text text-transparent">
                    QuizMaster
                  </span>
                </h1>
                <p className="mb-6 text-lg text-muted-foreground md:text-xl">
                  Desafie-se com perguntas sobre Artes, Música, Geografia, História e muito mais. Divirta-se enquanto aprende!
                </p>
                <div className="flex flex-col gap-4 sm:flex-row">
                  <Button asChild size="lg" variant="gradient">
                    <Link href="#temas">
                      Começar Quiz
                      <ArrowRight className="ml-2 h-5 w-5" />
                    </Link>
                  </Button>
                  <Button asChild size="lg" variant="outline">
                    <Link href="/ranking">
                      <Trophy className="mr-2 h-5 w-5" />
                      Ver Ranking
                    </Link>
                  </Button>
                </div>
              </div>
            </div>
            <div className="flex items-center justify-center">
              <div className="relative h-64 w-64 md:h-80 md:w-80">
                <Image
                  src="https://as1.ftcdn.net/v2/jpg/03/66/78/22/1000_F_366782280_pfIVQPMMCUoRu8kKgddZEtmXWRFbhqoN.jpg"
                  alt="Quiz illustration"
                  fill
                  className="object-contain"
                />
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="bg-muted/50 px-4 py-16">
        <div className="container mx-auto max-w-screen-xl">
          <div className="mb-12 text-center">
            <h2 className="mb-4 text-3xl font-bold md:text-4xl">Como Funciona</h2>
            <p className="mx-auto max-w-2xl text-muted-foreground">
              Nosso quiz é simples e divertido. Escolha um tema, responda às perguntas e veja sua pontuação no ranking!
            </p>
          </div>

          <div className="grid gap-8 md:grid-cols-3">
            {[
              {
                icon: <Brain className="h-10 w-10 text-primary" />,
                title: "Escolha um Tema",
                description:
                  "Selecione entre Artes, Música, Geografia, História do Brasil, História e Esportes.",
              },
              {
                icon: (
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    className="h-10 w-10 text-primary"
                    fill="none"
                    viewBox="0 0 24 24"
                    stroke="currentColor"
                  >
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth={2}
                      d="M8.228 9c.549-1.165 2.03-2 3.772-2 2.21 0 4 1.343 4 3 0 1.4-1.278 2.575-3.006 2.907-.542.104-.994.54-.994 1.093m0 3h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"
                    />
                  </svg>
                ),
                title: "Responda às Perguntas",
                description:
                  "Perguntas de múltipla escolha e verdadeiro ou falso com diferentes níveis de dificuldade.",
              },
              {
                icon: <Trophy className="h-10 w-10 text-primary" />,
                title: "Veja sua Pontuação",
                description:
                  "Ganhe pontos baseados na dificuldade e tempo de resposta. Compare com outros jogadores no ranking.",
              },
            ].map((feature, index) => (
              <div
                key={index}
                className="flex flex-col items-center rounded-xl bg-card p-6 text-center shadow-md"
              >
                <div className="mb-4 rounded-full bg-primary/10 p-3">{feature.icon}</div>
                <h3 className="mb-2 text-xl font-bold">{feature.title}</h3>
                <p className="text-muted-foreground">{feature.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Themes Section */}
      <section id="temas" className="px-4 py-16">
        <div className="container mx-auto max-w-screen-xl">
          <div className="mb-12 text-center">
            <h2 className="mb-4 text-3xl font-bold md:text-4xl">Escolha um Tema</h2>
            <p className="mx-auto max-w-2xl text-muted-foreground">
              Selecione um dos temas abaixo para começar seu quiz. Cada tema tem perguntas únicas para testar seus conhecimentos.
            </p>
          </div>

          <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
            <Suspense fallback={<div>Carregando temas...</div>}>
              {themes.map((theme, index) => (
                <QuizCardStatic
                  key={theme.id}
                  id={theme.id}
                  name={theme.name}
                  icon={theme.icon}
                  color={theme.color}
                  description={theme.description}
                  index={index}
                />
              ))}
            </Suspense>
          </div>
        </div>
      </section>
    </div>
  );
}