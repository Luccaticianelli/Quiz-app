import { type ClassValue, clsx } from "clsx";
import { twMerge } from "tailwind-merge";

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

export function shuffleArray<T>(array: T[]): T[] {
  const newArray = [...array];
  for (let i = newArray.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [newArray[i], newArray[j]] = [newArray[j], newArray[i]];
  }
  return newArray;
}

export function calculateScore(difficulty: string, timeRemaining: number): number {
  const baseScore = {
    easy: 100,
    medium: 200,
    hard: 300,
  }[difficulty] || 100;
  
  // Add time bonus (max 50% of base score)
  const timeBonus = Math.floor((timeRemaining / 30) * (baseScore * 0.5));
  
  return baseScore + timeBonus;
}

export const themes = [
  {
    id: "artes",
    name: "Artes",
    icon: "palette",
    color: "from-pink-500 to-rose-500",
    description: "Teste seus conhecimentos sobre pinturas, esculturas e movimentos artísticos"
  },
  {
    id: "musica",
    name: "Música",
    icon: "music",
    color: "from-purple-500 to-indigo-500",
    description: "Desafie-se com perguntas sobre artistas, bandas e história da música"
  },
  {
    id: "geografia",
    name: "Geografia",
    icon: "globe",
    color: "from-blue-500 to-cyan-500",
    description: "Explore seus conhecimentos sobre países, capitais e acidentes geográficos"
  },
  {
    id: "historia-brasil",
    name: "História do Brasil",
    icon: "landmark",
    color: "from-green-500 to-emerald-500",
    description: "Reviva os principais acontecimentos da história brasileira"
  },
  {
    id: "historia",
    name: "História",
    icon: "book-open",
    color: "from-amber-500 to-yellow-500",
    description: "Viaje pelo tempo com perguntas sobre a história mundial"
  },
  {
    id: "esportes",
    name: "Esportes",
    icon: "trophy",
    color: "from-red-500 to-orange-500",
    description: "Teste seu conhecimento sobre diferentes modalidades esportivas"
  }
];