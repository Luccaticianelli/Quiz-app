import { getServerSession } from "next-auth";
import { redirect } from "next/navigation";
import Link from "next/link";
import { ArrowLeft } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import QuestionPackForm from "@/components/admin/question-pack-form";
import { authOptions } from "@/lib/auth";

export const dynamic = "force-dynamic";

export default async function NewQuestionPackPage() {
  const session = await getServerSession(authOptions);
  
  if (!session?.user || session.user.role !== "ADMIN") {
    redirect("/auth/login?callbackUrl=/admin/question-packs/new");
  }

  return (
    <div className="container mx-auto max-w-screen-xl px-4 py-8">
      <div className="mb-6">
        <Link
          href="/admin/question-packs"
          className="inline-flex items-center text-sm text-muted-foreground hover:text-foreground"
        >
          <ArrowLeft className="mr-2 h-4 w-4" />
          Voltar para a lista de pacotes
        </Link>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Novo Pacote de Perguntas</CardTitle>
        </CardHeader>
        <CardContent>
          <QuestionPackForm />
        </CardContent>
      </Card>
    </div>
  );
}