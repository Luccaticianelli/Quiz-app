import { NextResponse } from "next/server";
import { getServerSession } from "next-auth";
import prisma from "@/lib/prisma";
import { authOptions } from "@/lib/auth";

export async function GET(
  request: Request,
  { params }: { params: { id: string } }
) {
  try {
    const session = await getServerSession(authOptions);

    if (!session?.user?.id || session.user.role !== "ADMIN") {
      return NextResponse.json(
        { error: "Não autorizado" },
        { status: 401 }
      );
    }

    const pack = await prisma.questionPack.findUnique({
      where: { id: params.id },
      include: {
        questions: true,
        _count: {
          select: {
            purchases: true,
          },
        },
      },
    });

    if (!pack) {
      return NextResponse.json(
        { error: "Pacote não encontrado" },
        { status: 404 }
      );
    }
    
    return NextResponse.json({ pack });
  } catch (error) {
    console.error("Error fetching question pack:", error);
    return NextResponse.json(
      { error: "Erro ao buscar pacote de perguntas" },
      { status: 500 }
    );
  }
}

export async function PATCH(
  request: Request,
  { params }: { params: { id: string } }
) {
  try {
    const session = await getServerSession(authOptions);

    if (!session?.user?.id || session.user.role !== "ADMIN") {
      return NextResponse.json(
        { error: "Não autorizado" },
        { status: 401 }
      );
    }

    const body = await request.json();
    const { name, description, price, theme, imageUrl, isActive } = body;

    if (!name || !description || price === undefined || !theme) {
      return NextResponse.json(
        { error: "Dados incompletos" },
        { status: 400 }
      );
    }

    const updatedPack = await prisma.questionPack.update({
      where: { id: params.id },
      data: {
        name,
        description,
        price,
        theme,
        imageUrl: imageUrl || null,
        isActive: isActive !== undefined ? isActive : true,
      },
    });
    
    return NextResponse.json({ pack: updatedPack });
  } catch (error) {
    console.error("Error updating question pack:", error);
    return NextResponse.json(
      { error: "Erro ao atualizar pacote de perguntas" },
      { status: 500 }
    );
  }
}

export async function DELETE(
  request: Request,
  { params }: { params: { id: string } }
) {
  try {
    const session = await getServerSession(authOptions);

    if (!session?.user?.id || session.user.role !== "ADMIN") {
      return NextResponse.json(
        { error: "Não autorizado" },
        { status: 401 }
      );
    }

    // Check if there are any purchases for this pack
    const purchaseCount = await prisma.purchase.count({
      where: { packId: params.id },
    });

    if (purchaseCount > 0) {
      // If there are purchases, just mark as inactive instead of deleting
      await prisma.questionPack.update({
        where: { id: params.id },
        data: { isActive: false },
      });
      
      return NextResponse.json({
        success: true,
        message: "Pacote marcado como inativo pois já possui compras",
      });
    }

    // If no purchases, delete the pack and its questions
    await prisma.$transaction([
      prisma.question.updateMany({
        where: { packId: params.id },
        data: { packId: null },
      }),
      prisma.questionPack.delete({
        where: { id: params.id },
      }),
    ]);
    
    return NextResponse.json({ success: true });
  } catch (error) {
    console.error("Error deleting question pack:", error);
    return NextResponse.json(
      { error: "Erro ao excluir pacote de perguntas" },
      { status: 500 }
    );
  }
}