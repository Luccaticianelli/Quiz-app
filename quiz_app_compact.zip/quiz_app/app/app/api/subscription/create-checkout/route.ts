import { NextResponse } from "next/server";
import { getServerSession } from "next-auth";
import prisma from "@/lib/prisma";
import { authOptions } from "@/lib/auth";

// This would be replaced with actual Stripe integration
const MOCK_CHECKOUT_URL = "https://example.com/checkout/session-id";

export async function POST(request: Request) {
  try {
    const session = await getServerSession(authOptions);

    if (!session?.user?.id) {
      return NextResponse.json(
        { error: "Não autorizado" },
        { status: 401 }
      );
    }

    const body = await request.json();
    const { plan } = body;

    if (plan !== "FREE" && plan !== "PREMIUM") {
      return NextResponse.json(
        { error: "Plano inválido" },
        { status: 400 }
      );
    }

    // For free plan, just update the subscription
    if (plan === "FREE") {
      await prisma.subscription.upsert({
        where: { userId: session.user.id },
        update: {
          plan: "FREE",
          status: "ACTIVE",
          endDate: null,
          cancelAtEnd: false,
        },
        create: {
          userId: session.user.id,
          plan: "FREE",
          status: "ACTIVE",
        },
      });

      return NextResponse.json({ success: true });
    }

    // For premium plan, in a real app, create a Stripe checkout session
    // For now, we'll just mock it
    
    // In a real implementation, this would create a Stripe checkout session
    // const stripe = new Stripe(process.env.STRIPE_SECRET_KEY);
    // const checkoutSession = await stripe.checkout.sessions.create({...});
    
    return NextResponse.json({
      url: MOCK_CHECKOUT_URL,
    });
  } catch (error) {
    console.error("Create checkout error:", error);
    return NextResponse.json(
      { error: "Erro ao processar assinatura" },
      { status: 500 }
    );
  }
}