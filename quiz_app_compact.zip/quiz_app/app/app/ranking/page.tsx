import { Suspense } from "react";
import { Trophy, Filter, Search } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import LeaderboardTable from "./leaderboard-table";

export const dynamic = "force-dynamic";

export default function RankingPage() {
  return (
    <div className="container mx-auto max-w-screen-xl px-4 py-8">
      <div className="mb-8 text-center">
        <h1 className="mb-2 text-3xl font-bold md:text-4xl">Ranking Global</h1>
        <p className="text-muted-foreground">
          Confira as melhores pontuações de todos os jogadores
        </p>
      </div>

      <div className="grid gap-6 md:grid-cols-4">
        <Card className="bg-gradient-to-br from-yellow-500 to-amber-600 text-white">
          <CardHeader className="pb-2">
            <CardTitle className="text-lg font-medium">Top Pontuação</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center gap-2">
              <Trophy className="h-5 w-5" />
              <span className="text-2xl font-bold">1250</span>
            </div>
            <p className="mt-1 text-xs text-white/80">Maria S. - História</p>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-br from-gray-400 to-gray-500 text-white">
          <CardHeader className="pb-2">
            <CardTitle className="text-lg font-medium">Jogadores Ativos</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center gap-2">
              <svg
                xmlns="http://www.w3.org/2000/svg"
                className="h-5 w-5"
                fill="none"
                viewBox="0 0 24 24"
                stroke="currentColor"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth={2}
                  d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z"
                />
              </svg>
              <span className="text-2xl font-bold">128</span>
            </div>
            <p className="mt-1 text-xs text-white/80">Última semana</p>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-br from-amber-700 to-amber-800 text-white">
          <CardHeader className="pb-2">
            <CardTitle className="text-lg font-medium">Total de Quizzes</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center gap-2">
              <svg
                xmlns="http://www.w3.org/2000/svg"
                className="h-5 w-5"
                fill="none"
                viewBox="0 0 24 24"
                stroke="currentColor"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth={2}
                  d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2"
                />
              </svg>
              <span className="text-2xl font-bold">543</span>
            </div>
            <p className="mt-1 text-xs text-white/80">Completados</p>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-br from-purple-500 to-indigo-600 text-white">
          <CardHeader className="pb-2">
            <CardTitle className="text-lg font-medium">Tema Popular</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center gap-2">
              <svg
                xmlns="http://www.w3.org/2000/svg"
                className="h-5 w-5"
                fill="none"
                viewBox="0 0 24 24"
                stroke="currentColor"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth={2}
                  d="M13 7h8m0 0v8m0-8l-8 8-4-4-6 6"
                />
              </svg>
              <span className="text-2xl font-bold">História</span>
            </div>
            <p className="mt-1 text-xs text-white/80">42% dos jogadores</p>
          </CardContent>
        </Card>
      </div>

      <div className="mt-8">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between">
            <CardTitle>Melhores Pontuações</CardTitle>
            <div className="flex items-center gap-2">
              <div className="relative">
                <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
                <input
                  type="text"
                  placeholder="Buscar jogador..."
                  className="h-9 rounded-md border border-input bg-background pl-8 pr-3 text-sm ring-offset-background file:border-0 file:bg-transparent file:text-sm file:font-medium placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50"
                />
              </div>
              <button className="inline-flex h-9 items-center justify-center rounded-md border border-input bg-background px-3 text-sm font-medium ring-offset-background transition-colors hover:bg-accent hover:text-accent-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50">
                <Filter className="mr-2 h-4 w-4" />
                Filtrar
              </button>
            </div>
          </CardHeader>
          <CardContent>
            <Suspense fallback={<div className="py-8 text-center">Carregando ranking...</div>}>
              <LeaderboardTable />
            </Suspense>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}