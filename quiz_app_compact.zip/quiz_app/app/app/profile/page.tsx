"use client";

import { useState } from "react";
import Image from "next/image";
import { motion } from "framer-motion";
import { User, Trophy, BarChart3, Clock, Calendar, Settings } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { themes } from "@/lib/utils";
import dynamic from "next/dynamic";

// Dynamically import the specific chart component with SSR disabled
const LineChart = dynamic(
  () => import("react-chartjs-2").then((mod) => mod.Line),
  {
    ssr: false,
    loading: () => <div className="h-64 w-full animate-pulse rounded-lg bg-muted"></div>,
  }
);

// Import Chart.js components
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Title,
  Tooltip,
  Legend,
} from "chart.js";

// Register Chart.js components
ChartJS.register(
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Title,
  Tooltip,
  Legend
);

// Mock user data
const userData = {
  name: "Carlos Oliveira",
  email: "carlos@example.com",
  joinedDate: "Março 2023",
  totalQuizzes: 42,
  averageScore: 720,
  bestScore: 950,
  bestTheme: "História",
  recentActivity: [
    { date: "10/06/2023", theme: "Geografia", score: 780 },
    { date: "05/06/2023", theme: "Música", score: 650 },
    { date: "01/06/2023", theme: "Artes", score: 820 },
    { date: "28/05/2023", theme: "História do Brasil", score: 710 },
    { date: "25/05/2023", theme: "Esportes", score: 590 },
  ],
  themePerformance: {
    labels: ["Artes", "Música", "Geografia", "História do Brasil", "História", "Esportes"],
    datasets: [
      {
        label: "Pontuação Média",
        data: [820, 650, 780, 710, 950, 590],
        borderColor: "rgb(99, 102, 241)",
        backgroundColor: "rgba(99, 102, 241, 0.5)",
        tension: 0.3,
      },
    ],
  },
};

export default function ProfilePage() {
  const [activeTab, setActiveTab] = useState("overview");

  const chartOptions = {
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
      legend: {
        position: "top" as const,
      },
    },
    scales: {
      y: {
        beginAtZero: true,
        max: 1000,
      },
    },
  };

  return (
    <div className="container mx-auto max-w-screen-xl px-4 py-8">
      <div className="mb-8 grid gap-6 md:grid-cols-[300px_1fr]">
        <motion.div
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.5 }}
        >
          <Card className="overflow-hidden">
            <div className="relative h-32 bg-gradient-to-r from-primary to-purple-600">
              <Button
                variant="ghost"
                size="icon"
                className="absolute right-2 top-2 z-10 text-white hover:bg-white/20"
              >
                <Settings className="h-5 w-5" />
              </Button>
            </div>
            <div className="relative -mt-16 px-6 text-center">
              <div className="mx-auto h-32 w-32 overflow-hidden rounded-full border-4 border-background bg-muted">
                <Image
                  src="https://i.pinimg.com/originals/07/33/ba/0733ba760b29378474dea0fdbcb97107.png"
                  alt="Profile"
                  fill
                  className="object-cover"
                />
              </div>
              <h2 className="mt-4 text-2xl font-bold">{userData.name}</h2>
              <p className="text-sm text-muted-foreground">{userData.email}</p>
              <div className="mt-4 flex items-center justify-center gap-2 text-sm text-muted-foreground">
                <Calendar className="h-4 w-4" />
                <span>Membro desde {userData.joinedDate}</span>
              </div>
            </div>
            <CardContent className="mt-6 border-t p-0">
              <ul className="divide-y">
                <li
                  className={`cursor-pointer px-6 py-3 transition-colors ${
                    activeTab === "overview" ? "bg-muted font-medium text-primary" : ""
                  }`}
                  onClick={() => setActiveTab("overview")}
                >
                  <div className="flex items-center gap-3">
                    <User className="h-5 w-5" />
                    <span>Visão Geral</span>
                  </div>
                </li>
                <li
                  className={`cursor-pointer px-6 py-3 transition-colors ${
                    activeTab === "statistics" ? "bg-muted font-medium text-primary" : ""
                  }`}
                  onClick={() => setActiveTab("statistics")}
                >
                  <div className="flex items-center gap-3">
                    <BarChart3 className="h-5 w-5" />
                    <span>Estatísticas</span>
                  </div>
                </li>
                <li
                  className={`cursor-pointer px-6 py-3 transition-colors ${
                    activeTab === "history" ? "bg-muted font-medium text-primary" : ""
                  }`}
                  onClick={() => setActiveTab("history")}
                >
                  <div className="flex items-center gap-3">
                    <Clock className="h-5 w-5" />
                    <span>Histórico</span>
                  </div>
                </li>
              </ul>
            </CardContent>
          </Card>
        </motion.div>

        <div>
          {activeTab === "overview" && (
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
              className="space-y-6"
            >
              <div className="grid gap-6 sm:grid-cols-3">
                <Card>
                  <CardHeader className="pb-2">
                    <CardTitle className="text-sm font-medium text-muted-foreground">
                      Total de Quizzes
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="text-2xl font-bold">{userData.totalQuizzes}</div>
                  </CardContent>
                </Card>
                <Card>
                  <CardHeader className="pb-2">
                    <CardTitle className="text-sm font-medium text-muted-foreground">
                      Pontuação Média
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="text-2xl font-bold">{userData.averageScore}</div>
                  </CardContent>
                </Card>
                <Card>
                  <CardHeader className="pb-2">
                    <CardTitle className="text-sm font-medium text-muted-foreground">
                      Melhor Tema
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="text-2xl font-bold">{userData.bestTheme}</div>
                  </CardContent>
                </Card>
              </div>

              <Card>
                <CardHeader>
                  <CardTitle>Desempenho por Tema</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="h-64">
                    <LineChart data={userData.themePerformance} options={chartOptions} />
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Atividade Recente</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {userData.recentActivity.map((activity, index) => {
                      const theme = themes.find(
                        (t) => t.name.toLowerCase() === activity.theme.toLowerCase()
                      );
                      
                      return (
                        <motion.div
                          key={index}
                          initial={{ opacity: 0, y: 10 }}
                          animate={{ opacity: 1, y: 0 }}
                          transition={{ duration: 0.3, delay: index * 0.1 }}
                          className="flex items-center justify-between rounded-lg border p-4"
                        >
                          <div className="flex items-center gap-4">
                            <div
                              className={`flex h-10 w-10 items-center justify-center rounded-full bg-gradient-to-r ${
                                theme?.color || "from-gray-500 to-gray-600"
                              } text-white`}
                            >
                              {theme?.icon && (
                                <span className="text-lg">
                                  {theme.icon.charAt(0).toUpperCase()}
                                </span>
                              )}
                            </div>
                            <div>
                              <p className="font-medium">{activity.theme}</p>
                              <p className="text-xs text-muted-foreground">
                                {activity.date}
                              </p>
                            </div>
                          </div>
                          <div className="text-xl font-bold">{activity.score}</div>
                        </motion.div>
                      );
                    })}
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          )}

          {activeTab === "statistics" && (
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
              className="space-y-6"
            >
              <Card>
                <CardHeader>
                  <CardTitle>Estatísticas Detalhadas</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid gap-6 sm:grid-cols-2">
                    <div className="space-y-2 rounded-lg border p-4">
                      <div className="flex items-center justify-between">
                        <span className="text-sm text-muted-foreground">
                          Melhor Pontuação
                        </span>
                        <span className="font-bold">{userData.bestScore}</span>
                      </div>
                      <div className="flex items-center justify-between">
                        <span className="text-sm text-muted-foreground">
                          Melhor Tema
                        </span>
                        <span className="font-bold">{userData.bestTheme}</span>
                      </div>
                      <div className="flex items-center justify-between">
                        <span className="text-sm text-muted-foreground">
                          Média de Pontos por Quiz
                        </span>
                        <span className="font-bold">{userData.averageScore}</span>
                      </div>
                    </div>
                    <div className="space-y-2 rounded-lg border p-4">
                      <div className="flex items-center justify-between">
                        <span className="text-sm text-muted-foreground">
                          Total de Quizzes
                        </span>
                        <span className="font-bold">{userData.totalQuizzes}</span>
                      </div>
                      <div className="flex items-center justify-between">
                        <span className="text-sm text-muted-foreground">
                          Taxa de Acerto
                        </span>
                        <span className="font-bold">76%</span>
                      </div>
                      <div className="flex items-center justify-between">
                        <span className="text-sm text-muted-foreground">
                          Tempo Médio por Pergunta
                        </span>
                        <span className="font-bold">18s</span>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Conquistas</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid gap-4 sm:grid-cols-2 md:grid-cols-3">
                    {[
                      {
                        title: "Mestre em História",
                        description: "Pontuação acima de 900 em História",
                        icon: <Trophy className="h-6 w-6 text-yellow-500" />,
                        unlocked: true,
                      },
                      {
                        title: "Explorador",
                        description: "Completou quizzes em todos os temas",
                        icon: <Trophy className="h-6 w-6 text-yellow-500" />,
                        unlocked: true,
                      },
                      {
                        title: "Velocista",
                        description: "Completou um quiz em menos de 2 minutos",
                        icon: <Trophy className="h-6 w-6 text-yellow-500" />,
                        unlocked: true,
                      },
                      {
                        title: "Perfeccionista",
                        description: "Acertou todas as perguntas em um quiz",
                        icon: <Trophy className="h-6 w-6 text-gray-400" />,
                        unlocked: false,
                      },
                      {
                        title: "Maratonista",
                        description: "Completou 10 quizzes em um dia",
                        icon: <Trophy className="h-6 w-6 text-gray-400" />,
                        unlocked: false,
                      },
                      {
                        title: "Lenda",
                        description: "Pontuação total acima de 50.000",
                        icon: <Trophy className="h-6 w-6 text-gray-400" />,
                        unlocked: false,
                      },
                    ].map((achievement, index) => (
                      <motion.div
                        key={index}
                        initial={{ opacity: 0, scale: 0.9 }}
                        animate={{ opacity: 1, scale: 1 }}
                        transition={{ duration: 0.3, delay: index * 0.1 }}
                        className={`rounded-lg border p-4 ${
                          !achievement.unlocked ? "opacity-50" : ""
                        }`}
                      >
                        <div className="mb-2 flex justify-between">
                          <div className="rounded-full bg-primary/10 p-2">
                            {achievement.icon}
                          </div>
                          {achievement.unlocked ? (
                            <span className="rounded-full bg-green-500/10 px-2 py-1 text-xs font-medium text-green-600">
                              Desbloqueado
                            </span>
                          ) : (
                            <span className="rounded-full bg-muted px-2 py-1 text-xs font-medium text-muted-foreground">
                              Bloqueado
                            </span>
                          )}
                        </div>
                        <h3 className="font-medium">{achievement.title}</h3>
                        <p className="text-xs text-muted-foreground">
                          {achievement.description}
                        </p>
                      </motion.div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          )}

          {activeTab === "history" && (
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
              className="space-y-6"
            >
              <Card>
                <CardHeader>
                  <CardTitle>Histórico de Quizzes</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {[
                      {
                        date: "12/06/2023",
                        time: "14:30",
                        theme: "História",
                        score: 950,
                        questions: 10,
                        correct: 9,
                      },
                      {
                        date: "10/06/2023",
                        time: "10:15",
                        theme: "Geografia",
                        score: 780,
                        questions: 10,
                        correct: 7,
                      },
                      {
                        date: "05/06/2023",
                        time: "19:45",
                        theme: "Música",
                        score: 650,
                        questions: 10,
                        correct: 6,
                      },
                      {
                        date: "01/06/2023",
                        time: "16:20",
                        theme: "Artes",
                        score: 820,
                        questions: 10,
                        correct: 8,
                      },
                      {
                        date: "28/05/2023",
                        time: "11:10",
                        theme: "História do Brasil",
                        score: 710,
                        questions: 10,
                        correct: 7,
                      },
                      {
                        date: "25/05/2023",
                        time: "20:30",
                        theme: "Esportes",
                        score: 590,
                        questions: 10,
                        correct: 5,
                      },
                      {
                        date: "20/05/2023",
                        time: "15:45",
                        theme: "História",
                        score: 880,
                        questions: 10,
                        correct: 8,
                      },
                      {
                        date: "18/05/2023",
                        time: "09:30",
                        theme: "Geografia",
                        score: 740,
                        questions: 10,
                        correct: 7,
                      },
                    ].map((quiz, index) => {
                      const theme = themes.find(
                        (t) => t.name.toLowerCase() === quiz.theme.toLowerCase()
                      );
                      
                      return (
                        <motion.div
                          key={index}
                          initial={{ opacity: 0, y: 10 }}
                          animate={{ opacity: 1, y: 0 }}
                          transition={{ duration: 0.3, delay: index * 0.05 }}
                          className="rounded-lg border p-4"
                        >
                          <div className="flex flex-wrap items-center justify-between gap-4">
                            <div className="flex items-center gap-4">
                              <div
                                className={`flex h-12 w-12 items-center justify-center rounded-full bg-gradient-to-r ${
                                  theme?.color || "from-gray-500 to-gray-600"
                                } text-white`}
                              >
                                {theme?.icon && (
                                  <span className="text-lg">
                                    {theme.icon.charAt(0).toUpperCase()}
                                  </span>
                                )}
                              </div>
                              <div>
                                <p className="font-medium">{quiz.theme}</p>
                                <p className="text-xs text-muted-foreground">
                                  {quiz.date} às {quiz.time}
                                </p>
                              </div>
                            </div>
                            <div className="flex items-center gap-6">
                              <div className="text-center">
                                <p className="text-xs text-muted-foreground">
                                  Acertos
                                </p>
                                <p className="font-medium">
                                  {quiz.correct}/{quiz.questions}
                                </p>
                              </div>
                              <div className="text-center">
                                <p className="text-xs text-muted-foreground">
                                  Pontuação
                                </p>
                                <p className="text-xl font-bold">{quiz.score}</p>
                              </div>
                            </div>
                          </div>
                        </motion.div>
                      );
                    })}
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          )}
        </div>
      </div>
    </div>
  );
}