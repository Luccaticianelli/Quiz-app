import { getServerSession } from "next-auth";
import { redirect } from "next/navigation";
import Link from "next/link";
import Image from "next/image";
import { Plus, Search, Filter, Package } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { authOptions } from "@/lib/auth";
import prisma from "@/lib/prisma";

export const dynamic = "force-dynamic";

export default async function AdminQuestionPacksPage() {
  const session = await getServerSession(authOptions);
  
  if (!session?.user || session.user.role !== "ADMIN") {
    redirect("/auth/login?callbackUrl=/admin/question-packs");
  }

  const packs = await prisma.questionPack.findMany({
    orderBy: {
      createdAt: "desc",
    },
    include: {
      _count: {
        select: {
          questions: true,
          purchases: true,
        },
      },
    },
  });

  return (
    <div className="container mx-auto max-w-screen-xl px-4 py-8">
      <div className="mb-8 flex flex-col justify-between gap-4 md:flex-row md:items-center">
        <div>
          <h1 className="text-3xl font-bold">Gerenciar Pacotes</h1>
          <p className="text-muted-foreground">
            Adicione, edite e exclua pacotes de perguntas
          </p>
        </div>
        <Button asChild>
          <Link href="/admin/question-packs/new">
            <Plus className="mr-2 h-4 w-4" />
            Novo Pacote
          </Link>
        </Button>
      </div>

      <div className="mb-6 flex flex-col gap-4 sm:flex-row">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
          <input
            type="text"
            placeholder="Buscar pacotes..."
            className="w-full rounded-md border border-input bg-background py-2 pl-10 pr-4 text-sm ring-offset-background file:border-0 file:bg-transparent file:text-sm file:font-medium placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50"
          />
        </div>
        <div className="flex gap-2">
          <select className="rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2">
            <option value="">Todos os temas</option>
            <option value="Artes">Artes</option>
            <option value="Música">Música</option>
            <option value="Geografia">Geografia</option>
            <option value="História do Brasil">História do Brasil</option>
            <option value="História">História</option>
            <option value="Esportes">Esportes</option>
          </select>
          <button className="inline-flex items-center rounded-md border border-input bg-background px-4 py-2 text-sm font-medium ring-offset-background transition-colors hover:bg-accent hover:text-accent-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50">
            <Filter className="mr-2 h-4 w-4" />
            Filtrar
          </button>
        </div>
      </div>

      <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
        {packs.length === 0 ? (
          <div className="col-span-full flex min-h-[300px] flex-col items-center justify-center rounded-lg border border-dashed p-8 text-center">
            <Package className="mb-4 h-12 w-12 text-muted-foreground" />
            <h3 className="mb-2 text-xl font-medium">Nenhum pacote encontrado</h3>
            <p className="mb-4 text-muted-foreground">
              Comece criando seu primeiro pacote de perguntas
            </p>
            <Button asChild>
              <Link href="/admin/question-packs/new">
                <Plus className="mr-2 h-4 w-4" />
                Criar Pacote
              </Link>
            </Button>
          </div>
        ) : (
          packs.map((pack) => (
            <Card key={pack.id} className="overflow-hidden">
              <div className="relative h-40 w-full">
                <Image
                  src={
                    pack.imageUrl ||
                    "https://images.unsplash.com/photo-1606326608606-aa0b62935f2b?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=2070&q=80"
                  }
                  alt={pack.name}
                  fill
                  className="object-cover"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/70 to-transparent" />
                <div className="absolute bottom-0 left-0 right-0 p-4">
                  <div className="flex items-center justify-between">
                    <div className="inline-flex rounded-full bg-primary/20 px-2 py-1 text-xs font-medium text-primary backdrop-blur-sm">
                      {pack.theme}
                    </div>
                    {pack.isActive ? (
                      <div className="inline-flex rounded-full bg-green-500/20 px-2 py-1 text-xs font-medium text-green-500 backdrop-blur-sm">
                        Ativo
                      </div>
                    ) : (
                      <div className="inline-flex rounded-full bg-red-500/20 px-2 py-1 text-xs font-medium text-red-500 backdrop-blur-sm">
                        Inativo
                      </div>
                    )}
                  </div>
                </div>
              </div>
              <CardHeader>
                <CardTitle>{pack.name}</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="mb-4 text-sm text-muted-foreground">
                  {pack.description}
                </p>
                <div className="mb-4 grid grid-cols-2 gap-4">
                  <div className="rounded-lg border p-2 text-center">
                    <p className="text-xs text-muted-foreground">Preço</p>
                    <p className="font-bold">R$ {pack.price.toFixed(2)}</p>
                  </div>
                  <div className="rounded-lg border p-2 text-center">
                    <p className="text-xs text-muted-foreground">Perguntas</p>
                    <p className="font-bold">{pack._count.questions}</p>
                  </div>
                </div>
                <div className="flex justify-between">
                  <Button asChild variant="outline" size="sm">
                    <Link href={`/admin/question-packs/${pack.id}`}>
                      Editar
                    </Link>
                  </Button>
                  <Button asChild variant="outline" size="sm">
                    <Link href={`/admin/question-packs/${pack.id}/questions`}>
                      Gerenciar Perguntas
                    </Link>
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))
        )}
      </div>
    </div>
  );
}