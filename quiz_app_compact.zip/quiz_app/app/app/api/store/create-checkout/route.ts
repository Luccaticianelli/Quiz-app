import { NextResponse } from "next/server";
import { getServerSession } from "next-auth";
import prisma from "@/lib/prisma";
import { authOptions } from "@/lib/auth";

// This would be replaced with actual Stripe integration
const MOCK_CHECKOUT_URL = "https://example.com/checkout/session-id";

export async function POST(request: Request) {
  try {
    const session = await getServerSession(authOptions);

    if (!session?.user?.id) {
      return NextResponse.json(
        { error: "Não autorizado" },
        { status: 401 }
      );
    }

    const body = await request.json();
    const { packId } = body;

    if (!packId) {
      return NextResponse.json(
        { error: "ID do pacote não fornecido" },
        { status: 400 }
      );
    }

    // Check if pack exists and is active
    const pack = await prisma.questionPack.findUnique({
      where: { id: packId, isActive: true },
    });

    if (!pack) {
      return NextResponse.json(
        { error: "Pacote não encontrado ou inativo" },
        { status: 404 }
      );
    }

    // Check if user already purchased this pack
    const existingPurchase = await prisma.purchase.findFirst({
      where: {
        userId: session.user.id,
        packId,
        status: "COMPLETED",
      },
    });

    if (existingPurchase) {
      return NextResponse.json(
        { error: "Você já adquiriu este pacote" },
        { status: 400 }
      );
    }

    // In a real implementation, this would create a Stripe checkout session
    // const stripe = new Stripe(process.env.STRIPE_SECRET_KEY);
    // const checkoutSession = await stripe.checkout.sessions.create({...});
    
    // Create a pending purchase record
    await prisma.purchase.create({
      data: {
        userId: session.user.id,
        packId,
        amount: pack.price,
        status: "PENDING",
      },
    });
    
    return NextResponse.json({
      url: MOCK_CHECKOUT_URL,
    });
  } catch (error) {
    console.error("Create checkout error:", error);
    return NextResponse.json(
      { error: "Erro ao processar compra" },
      { status: 500 }
    );
  }
}