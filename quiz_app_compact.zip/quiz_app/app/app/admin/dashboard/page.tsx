import { getServerSession } from "next-auth";
import { redirect } from "next/navigation";
import Link from "next/link";
import {
  Users,
  ShoppingCart,
  CreditCard,
  HelpCircle,
  BarChart3,
  Plus,
} from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { authOptions } from "@/lib/auth";
import prisma from "@/lib/prisma";

export const dynamic = "force-dynamic";

export default async function AdminDashboardPage() {
  const session = await getServerSession(authOptions);
  
  if (!session?.user || session.user.role !== "ADMIN") {
    redirect("/auth/login?callbackUrl=/admin/dashboard");
  }

  // Get counts for dashboard
  const [
    userCount,
    questionCount,
    packCount,
    purchaseCount,
    premiumUserCount,
  ] = await Promise.all([
    prisma.user.count(),
    prisma.question.count(),
    prisma.questionPack.count(),
    prisma.purchase.count({
      where: { status: "COMPLETED" },
    }),
    prisma.subscription.count({
      where: {
        plan: "PREMIUM",
        status: "ACTIVE",
      },
    }),
  ]);

  // Get recent purchases
  const recentPurchases = await prisma.purchase.findMany({
    where: { status: "COMPLETED" },
    orderBy: { createdAt: "desc" },
    take: 5,
    include: {
      user: {
        select: { name: true, email: true },
      },
      pack: {
        select: { name: true },
      },
    },
  });

  return (
    <div className="container mx-auto max-w-screen-xl px-4 py-8">
      <div className="mb-8 flex flex-col justify-between gap-4 md:flex-row md:items-center">
        <div>
          <h1 className="text-3xl font-bold">Painel Administrativo</h1>
          <p className="text-muted-foreground">
            Gerencie perguntas, pacotes e monitore o desempenho do aplicativo
          </p>
        </div>
        <div className="flex gap-2">
          <Button asChild variant="outline">
            <Link href="/admin/questions/new">
              <Plus className="mr-2 h-4 w-4" />
              Nova Pergunta
            </Link>
          </Button>
          <Button asChild>
            <Link href="/admin/question-packs/new">
              <Plus className="mr-2 h-4 w-4" />
              Novo Pacote
            </Link>
          </Button>
        </div>
      </div>

      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-4">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">
              Usuários Totais
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center justify-between">
              <div className="text-2xl font-bold">{userCount}</div>
              <Users className="h-5 w-5 text-muted-foreground" />
            </div>
            <p className="mt-2 text-xs text-muted-foreground">
              {premiumUserCount} usuários premium
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">
              Perguntas
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center justify-between">
              <div className="text-2xl font-bold">{questionCount}</div>
              <HelpCircle className="h-5 w-5 text-muted-foreground" />
            </div>
            <p className="mt-2 text-xs text-muted-foreground">
              Em {packCount} pacotes
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">
              Vendas
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center justify-between">
              <div className="text-2xl font-bold">{purchaseCount}</div>
              <ShoppingCart className="h-5 w-5 text-muted-foreground" />
            </div>
            <p className="mt-2 text-xs text-muted-foreground">
              Pacotes vendidos
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">
              Receita Estimada
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center justify-between">
              <div className="text-2xl font-bold">R$ {(premiumUserCount * 9.99 + purchaseCount * 4.99).toFixed(2)}</div>
              <CreditCard className="h-5 w-5 text-muted-foreground" />
            </div>
            <p className="mt-2 text-xs text-muted-foreground">
              Assinaturas + vendas
            </p>
          </CardContent>
        </Card>
      </div>

      <div className="mt-8 grid gap-6 md:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle>Compras Recentes</CardTitle>
          </CardHeader>
          <CardContent>
            {recentPurchases.length > 0 ? (
              <div className="space-y-4">
                {recentPurchases.map((purchase) => (
                  <div
                    key={purchase.id}
                    className="flex items-center justify-between rounded-lg border p-4"
                  >
                    <div>
                      <p className="font-medium">{purchase.user.name}</p>
                      <p className="text-xs text-muted-foreground">
                        Comprou: {purchase.pack.name}
                      </p>
                      <p className="text-xs text-muted-foreground">
                        {new Date(purchase.createdAt).toLocaleDateString()}
                      </p>
                    </div>
                    <div className="text-right">
                      <p className="font-bold">R$ {purchase.amount.toFixed(2)}</p>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="flex h-40 items-center justify-center text-muted-foreground">
                Nenhuma compra recente
              </div>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Distribuição de Usuários</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="h-[240px] w-full">
              <div className="flex h-full flex-col items-center justify-center">
                <BarChart3 className="mb-4 h-16 w-16 text-muted-foreground" />
                <p className="text-center text-muted-foreground">
                  Gráficos detalhados disponíveis na seção de análises
                </p>
                <Button asChild variant="outline" className="mt-4">
                  <Link href="/admin/analytics">Ver Análises</Link>
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="mt-8 grid gap-6 md:grid-cols-3">
        <Card className="md:col-span-2">
          <CardHeader>
            <CardTitle>Links Rápidos</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid gap-4 sm:grid-cols-2 md:grid-cols-3">
              <Link
                href="/admin/questions"
                className="flex flex-col items-center rounded-lg border p-4 transition-colors hover:bg-accent"
              >
                <HelpCircle className="mb-2 h-8 w-8 text-primary" />
                <span className="text-center font-medium">Gerenciar Perguntas</span>
              </Link>
              <Link
                href="/admin/question-packs"
                className="flex flex-col items-center rounded-lg border p-4 transition-colors hover:bg-accent"
              >
                <ShoppingCart className="mb-2 h-8 w-8 text-primary" />
                <span className="text-center font-medium">Gerenciar Pacotes</span>
              </Link>
              <Link
                href="/admin/users"
                className="flex flex-col items-center rounded-lg border p-4 transition-colors hover:bg-accent"
              >
                <Users className="mb-2 h-8 w-8 text-primary" />
                <span className="text-center font-medium">Gerenciar Usuários</span>
              </Link>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Suporte</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <p className="text-muted-foreground">
                Precisa de ajuda com o painel administrativo?
              </p>
              <Button asChild variant="outline" className="w-full">
                <a href="mailto:suporte@quizmaster.com">Contatar Suporte</a>
              </Button>
              <Button asChild variant="outline" className="w-full">
                <Link href="/admin/documentation">Ver Documentação</Link>
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}