import Link from "next/link";
import { cn } from "@/lib/utils";
import { 
  Palette, Music, Globe, Landmark, BookOpen, Trophy 
} from "lucide-react";

interface QuizCardStaticProps {
  id: string;
  name: string;
  icon: string;
  color: string;
  description: string;
  index: number;
}

const QuizCardStatic = ({ id, name, icon, color, description, index }: QuizCardStaticProps) => {
  // Get the icon component based on the icon name
  const getIcon = () => {
    switch (icon) {
      case "palette":
        return <Palette className="h-6 w-6" />;
      case "music":
        return <Music className="h-6 w-6" />;
      case "globe":
        return <Globe className="h-6 w-6" />;
      case "landmark":
        return <Landmark className="h-6 w-6" />;
      case "book-open":
        return <BookOpen className="h-6 w-6" />;
      case "trophy":
        return <Trophy className="h-6 w-6" />;
      default:
        return null;
    }
  };

  return (
    <div
      className={cn(
        "quiz-card bg-gradient-to-br",
        color
      )}
    >
      <Link href={`/quiz/${id}`} className="block h-full">
        <div className="quiz-card-content flex h-full flex-col justify-between">
          <div className="mb-4">
            <div
              className="mb-4 flex h-12 w-12 items-center justify-center rounded-full bg-white/20 text-white backdrop-blur-sm"
            >
              {getIcon()}
            </div>
            <h3 className="mb-2 text-2xl font-bold text-white">{name}</h3>
            <p className="text-sm text-white/80">{description}</p>
          </div>
          <div
            className="mt-4 flex items-center text-sm font-medium text-white"
          >
            Iniciar Quiz
            <svg
              xmlns="http://www.w3.org/2000/svg"
              className="ml-2 h-4 w-4"
              fill="none"
              viewBox="0 0 24 24"
              stroke="currentColor"
            >
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                strokeWidth={2}
                d="M9 5l7 7-7 7"
              />
            </svg>
          </div>
        </div>
      </Link>
    </div>
  );
};

export default QuizCardStatic;