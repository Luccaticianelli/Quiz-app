import { getServerSession } from "next-auth";
import { redirect } from "next/navigation";
import Link from "next/link";
import { ArrowLeft } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import QuestionForm from "@/components/admin/question-form";
import { authOptions } from "@/lib/auth";
import prisma from "@/lib/prisma";

export const dynamic = "force-dynamic";

export default async function NewQuestionPage() {
  const session = await getServerSession(authOptions);
  
  if (!session?.user || session.user.role !== "ADMIN") {
    redirect("/auth/login?callbackUrl=/admin/questions/new");
  }

  const questionPacks = await prisma.questionPack.findMany({
    where: { isActive: true },
    select: { id: true, name: true },
    orderBy: { name: "asc" },
  });

  return (
    <div className="container mx-auto max-w-screen-xl px-4 py-8">
      <div className="mb-6">
        <Link
          href="/admin/questions"
          className="inline-flex items-center text-sm text-muted-foreground hover:text-foreground"
        >
          <ArrowLeft className="mr-2 h-4 w-4" />
          Voltar para a lista de perguntas
        </Link>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Nova Pergunta</CardTitle>
        </CardHeader>
        <CardContent>
          <QuestionForm questionPacks={questionPacks} />
        </CardContent>
      </Card>
    </div>
  );
}