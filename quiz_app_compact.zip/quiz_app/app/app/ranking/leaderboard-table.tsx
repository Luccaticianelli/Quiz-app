"use client";

import { useState } from "react";
import { motion } from "framer-motion";
import { Trophy, Medal, Award } from "lucide-react";
import { themes } from "@/lib/utils";

// Mock data for the leaderboard
const mockLeaderboardData = [
  { id: 1, name: "Maria Silva", score: 1250, theme: "História" },
  { id: 2, name: "João Santos", score: 1180, theme: "Geografia" },
  { id: 3, name: "Ana Oliveira", score: 1050, theme: "Artes" },
  { id: 4, name: "Pedro Costa", score: 980, theme: "Música" },
  { id: 5, name: "Carla Souza", score: 920, theme: "Esportes" },
  { id: 6, name: "Lucas Ferreira", score: 890, theme: "História do Brasil" },
  { id: 7, name: "Juliana Lima", score: 850, theme: "Artes" },
  { id: 8, name: "Roberto Alves", score: 820, theme: "Geografia" },
  { id: 9, name: "Fernanda Dias", score: 790, theme: "Música" },
  { id: 10, name: "Marcelo Gomes", score: 760, theme: "Esportes" },
];

export default function LeaderboardTable() {
  const [sortBy, setSortBy] = useState<"score" | "name">("score");
  const [sortOrder, setSortOrder] = useState<"asc" | "desc">("desc");

  const handleSort = (column: "score" | "name") => {
    if (sortBy === column) {
      setSortOrder(sortOrder === "asc" ? "desc" : "asc");
    } else {
      setSortBy(column);
      setSortOrder("desc");
    }
  };

  const sortedData = [...mockLeaderboardData].sort((a, b) => {
    if (sortBy === "score") {
      return sortOrder === "asc" ? a.score - b.score : b.score - a.score;
    } else {
      return sortOrder === "asc"
        ? a.name.localeCompare(b.name)
        : b.name.localeCompare(a.name);
    }
  });

  const getThemeColor = (themeName: string) => {
    const theme = themes.find(
      (t) => t.name.toLowerCase() === themeName.toLowerCase()
    );
    return theme?.color || "from-gray-500 to-gray-600";
  };

  const getPositionIcon = (position: number) => {
    switch (position) {
      case 1:
        return <Trophy className="h-5 w-5 text-yellow-500" />;
      case 2:
        return <Medal className="h-5 w-5 text-gray-400" />;
      case 3:
        return <Award className="h-5 w-5 text-amber-700" />;
      default:
        return <span className="text-sm font-medium">{position}</span>;
    }
  };

  return (
    <div className="overflow-x-auto">
      <table className="w-full border-collapse">
        <thead>
          <tr className="border-b">
            <th className="px-4 py-3 text-left text-sm font-medium text-muted-foreground">
              Posição
            </th>
            <th
              className="cursor-pointer px-4 py-3 text-left text-sm font-medium text-muted-foreground"
              onClick={() => handleSort("name")}
            >
              <div className="flex items-center">
                Jogador
                {sortBy === "name" && (
                  <span className="ml-1">
                    {sortOrder === "asc" ? "↑" : "↓"}
                  </span>
                )}
              </div>
            </th>
            <th className="px-4 py-3 text-left text-sm font-medium text-muted-foreground">
              Tema
            </th>
            <th
              className="cursor-pointer px-4 py-3 text-right text-sm font-medium text-muted-foreground"
              onClick={() => handleSort("score")}
            >
              <div className="flex items-center justify-end">
                Pontuação
                {sortBy === "score" && (
                  <span className="ml-1">
                    {sortOrder === "asc" ? "↑" : "↓"}
                  </span>
                )}
              </div>
            </th>
          </tr>
        </thead>
        <tbody>
          {sortedData.map((entry, index) => {
            const position = sortBy === "score" && sortOrder === "desc" ? index + 1 : null;
            
            return (
              <motion.tr
                key={entry.id}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.3, delay: index * 0.05 }}
                className="border-b"
              >
                <td className="px-4 py-3">
                  <div className="flex h-8 w-8 items-center justify-center">
                    {getPositionIcon(position || index + 1)}
                  </div>
                </td>
                <td className="px-4 py-3 font-medium">{entry.name}</td>
                <td className="px-4 py-3">
                  <div className="inline-flex items-center rounded-full bg-gradient-to-r px-2.5 py-0.5 text-xs font-medium text-white">
                    <span
                      className={`inline-block h-2 w-2 rounded-full bg-white/80`}
                    ></span>
                    <span className="ml-1.5">{entry.theme}</span>
                  </div>
                </td>
                <td className="px-4 py-3 text-right font-bold">{entry.score}</td>
              </motion.tr>
            );
          })}
        </tbody>
      </table>
    </div>
  );
}