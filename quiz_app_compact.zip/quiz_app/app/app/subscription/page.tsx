import { getServerSession } from "next-auth";
import { redirect } from "next/navigation";
import { CreditCard, Shield, Zap, CheckCircle2 } from "lucide-react";
import PricingCard from "@/components/subscription/pricing-card";
import { authOptions } from "@/lib/auth";
import prisma from "@/lib/prisma";

export const dynamic = "force-dynamic";

export default async function SubscriptionPage() {
  const session = await getServerSession(authOptions);
  
  if (!session?.user) {
    redirect("/auth/login?callbackUrl=/subscription");
  }

  const subscription = await prisma.subscription.findUnique({
    where: { userId: session.user.id },
  });

  const currentPlan = subscription?.plan || "FREE";

  return (
    <div className="container mx-auto max-w-screen-xl px-4 py-16">
      <div className="mb-12 text-center">
        <h1 className="mb-4 text-4xl font-bold">Planos de Assinatura</h1>
        <p className="mx-auto max-w-2xl text-muted-foreground">
          Escolha o plano que melhor se adapta às suas necessidades e desbloqueie recursos premium para aprimorar sua experiência de aprendizado.
        </p>
      </div>

      <div className="grid gap-8 md:grid-cols-2">
        <PricingCard
          title="Plano Gratuito"
          price={0}
          description="Acesso básico para começar sua jornada de conhecimento"
          features={[
            "Acesso a quizzes básicos",
            "Temas limitados",
            "Ranking global",
            "Estatísticas básicas",
          ]}
          isPremium={false}
          isCurrentPlan={currentPlan === "FREE"}
          userId={session.user.id}
        />

        <PricingCard
          title="Plano Premium"
          price={9.99}
          description="Acesso completo a todos os recursos e conteúdos exclusivos"
          features={[
            "Acesso a todos os quizzes",
            "Conteúdo exclusivo premium",
            "Estatísticas avançadas",
            "Sem anúncios",
            "Suporte prioritário",
          ]}
          isPopular={true}
          isPremium={true}
          isCurrentPlan={currentPlan === "PREMIUM"}
          userId={session.user.id}
        />
      </div>

      <div className="mt-16">
        <h2 className="mb-8 text-center text-2xl font-bold">Por que assinar o plano Premium?</h2>
        <div className="grid gap-8 md:grid-cols-3">
          <div className="rounded-lg border bg-card p-6 shadow-sm">
            <div className="mb-4 flex h-12 w-12 items-center justify-center rounded-full bg-primary/10">
              <Zap className="h-6 w-6 text-primary" />
            </div>
            <h3 className="mb-2 text-xl font-bold">Conteúdo Exclusivo</h3>
            <p className="text-muted-foreground">
              Acesse perguntas premium e temas exclusivos disponíveis apenas para assinantes.
            </p>
          </div>

          <div className="rounded-lg border bg-card p-6 shadow-sm">
            <div className="mb-4 flex h-12 w-12 items-center justify-center rounded-full bg-primary/10">
              <Shield className="h-6 w-6 text-primary" />
            </div>
            <h3 className="mb-2 text-xl font-bold">Experiência Sem Anúncios</h3>
            <p className="text-muted-foreground">
              Desfrute de uma experiência de aprendizado sem interrupções e distrações.
            </p>
          </div>

          <div className="rounded-lg border bg-card p-6 shadow-sm">
            <div className="mb-4 flex h-12 w-12 items-center justify-center rounded-full bg-primary/10">
              <CheckCircle2 className="h-6 w-6 text-primary" />
            </div>
            <h3 className="mb-2 text-xl font-bold">Estatísticas Avançadas</h3>
            <p className="text-muted-foreground">
              Acompanhe seu progresso com análises detalhadas e relatórios personalizados.
            </p>
          </div>
        </div>
      </div>

      <div className="mt-16 rounded-lg border bg-card p-8">
        <div className="flex flex-col items-center gap-6 md:flex-row md:justify-between">
          <div>
            <h3 className="text-xl font-bold">Precisa de ajuda para escolher?</h3>
            <p className="text-muted-foreground">
              Entre em contato com nosso suporte para tirar suas dúvidas sobre os planos.
            </p>
          </div>
          <a
            href="mailto:suporte@quizmaster.com"
            className="inline-flex items-center rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground hover:bg-primary/90"
          >
            <CreditCard className="mr-2 h-4 w-4" />
            Fale com o Suporte
          </a>
        </div>
      </div>
    </div>
  );
}