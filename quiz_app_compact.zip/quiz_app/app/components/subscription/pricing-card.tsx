"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { motion } from "framer-motion";
import { Check, Loader2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useToast } from "@/components/ui/use-toast";
import { cn } from "@/lib/utils";

interface PricingCardProps {
  title: string;
  price: number;
  description: string;
  features: string[];
  isPopular?: boolean;
  isPremium: boolean;
  isCurrentPlan?: boolean;
  userId?: string;
}

export default function PricingCard({
  title,
  price,
  description,
  features,
  isPopular = false,
  isPremium,
  isCurrentPlan = false,
  userId,
}: PricingCardProps) {
  const [isLoading, setIsLoading] = useState(false);
  const router = useRouter();
  const { toast } = useToast();

  const handleSubscribe = async () => {
    if (!userId) {
      router.push("/auth/login?callbackUrl=/subscription");
      return;
    }

    setIsLoading(true);

    try {
      const response = await fetch("/api/subscription/create-checkout", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          plan: isPremium ? "PREMIUM" : "FREE",
        }),
      });

      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.error || "Erro ao processar assinatura");
      }

      // For free plan, just update the subscription
      if (!isPremium) {
        toast({
          title: "Plano atualizado com sucesso!",
          description: "Você está agora no plano gratuito.",
        });
        router.refresh();
        return;
      }

      // For premium plan, redirect to Stripe checkout
      if (data.url) {
        window.location.href = data.url;
      }
    } catch (error: any) {
      console.error("Subscription error:", error);
      toast({
        title: "Erro ao processar assinatura",
        description: error.message || "Tente novamente mais tarde.",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
      className={cn(
        "relative flex flex-col rounded-xl border bg-card p-6 shadow-lg",
        isPopular && "border-primary shadow-primary/20"
      )}
    >
      {isPopular && (
        <div className="absolute -top-3 left-1/2 -translate-x-1/2 rounded-full bg-primary px-3 py-1 text-xs font-medium text-primary-foreground">
          Mais Popular
        </div>
      )}

      <div className="mb-4 mt-2 text-center">
        <h3 className="text-xl font-bold">{title}</h3>
        <div className="mt-2">
          <span className="text-3xl font-bold">
            {price === 0 ? "Grátis" : `R$${price}`}
          </span>
          {price > 0 && <span className="text-muted-foreground">/mês</span>}
        </div>
        <p className="mt-2 text-sm text-muted-foreground">{description}</p>
      </div>

      <ul className="mb-6 space-y-2">
        {features.map((feature, index) => (
          <li key={index} className="flex items-center gap-2 text-sm">
            <Check className="h-4 w-4 text-green-500" />
            <span>{feature}</span>
          </li>
        ))}
      </ul>

      <div className="mt-auto">
        <Button
          onClick={handleSubscribe}
          disabled={isLoading || isCurrentPlan}
          variant={isPremium ? "gradient" : "outline"}
          className="w-full"
        >
          {isLoading ? (
            <Loader2 className="mr-2 h-4 w-4 animate-spin" />
          ) : isCurrentPlan ? (
            "Plano Atual"
          ) : (
            "Assinar"
          )}
        </Button>
      </div>
    </motion.div>
  );
}