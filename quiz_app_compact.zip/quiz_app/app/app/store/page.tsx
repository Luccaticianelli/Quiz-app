import { getServerSession } from "next-auth";
import { ShoppingCart, Filter, Search } from "lucide-react";
import QuestionPackCard from "@/components/subscription/question-pack-card";
import { authOptions } from "@/lib/auth";
import prisma from "@/lib/prisma";

export const dynamic = "force-dynamic";

export default async function StorePage() {
  const session = await getServerSession(authOptions);
  const userId = session?.user?.id;

  // Get all active question packs
  const packs = await prisma.questionPack.findMany({
    where: {
      isActive: true,
    },
    orderBy: {
      createdAt: "desc",
    },
  });

  // Get user purchases if logged in
  const purchases = userId
    ? await prisma.purchase.findMany({
        where: {
          userId,
          status: "COMPLETED",
        },
        select: {
          packId: true,
        },
      })
    : [];

  const purchasedPackIds = purchases.map((purchase) => purchase.packId);

  return (
    <div className="container mx-auto max-w-screen-xl px-4 py-16">
      <div className="mb-12 text-center">
        <h1 className="mb-4 text-4xl font-bold">Loja de Pacotes</h1>
        <p className="mx-auto max-w-2xl text-muted-foreground">
          Expanda seu conhecimento com pacotes de perguntas temáticos. Cada pacote contém perguntas exclusivas para testar e aprimorar seus conhecimentos.
        </p>
      </div>

      <div className="mb-8 flex flex-col items-center justify-between gap-4 sm:flex-row">
        <div className="relative w-full max-w-md">
          <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
          <input
            type="text"
            placeholder="Buscar pacotes..."
            className="w-full rounded-md border border-input bg-background py-2 pl-10 pr-4 text-sm ring-offset-background file:border-0 file:bg-transparent file:text-sm file:font-medium placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50"
          />
        </div>
        <div className="flex items-center gap-2">
          <button className="inline-flex items-center rounded-md border border-input bg-background px-4 py-2 text-sm font-medium ring-offset-background transition-colors hover:bg-accent hover:text-accent-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50">
            <Filter className="mr-2 h-4 w-4" />
            Filtrar
          </button>
          <select className="rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2">
            <option value="recent">Mais recentes</option>
            <option value="price-asc">Preço: Menor para maior</option>
            <option value="price-desc">Preço: Maior para menor</option>
            <option value="name">Nome</option>
          </select>
        </div>
      </div>

      {packs.length === 0 ? (
        <div className="flex min-h-[300px] flex-col items-center justify-center rounded-lg border border-dashed p-8 text-center">
          <ShoppingCart className="mb-4 h-12 w-12 text-muted-foreground" />
          <h3 className="mb-2 text-xl font-medium">Nenhum pacote disponível</h3>
          <p className="text-muted-foreground">
            Não há pacotes de perguntas disponíveis no momento. Volte mais tarde!
          </p>
        </div>
      ) : (
        <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {packs.map((pack) => (
            <QuestionPackCard
              key={pack.id}
              id={pack.id}
              name={pack.name}
              description={pack.description}
              price={pack.price}
              imageUrl={pack.imageUrl || undefined}
              theme={pack.theme}
              isPurchased={purchasedPackIds.includes(pack.id)}
              userId={userId}
            />
          ))}
        </div>
      )}

      <div className="mt-16 rounded-lg border bg-card p-8">
        <div className="flex flex-col items-center gap-6 md:flex-row md:justify-between">
          <div>
            <h3 className="text-xl font-bold">Não encontrou o que procura?</h3>
            <p className="text-muted-foreground">
              Sugira novos temas e pacotes de perguntas para nossa equipe.
            </p>
          </div>
          <a
            href="mailto:sugestoes@quizmaster.com"
            className="inline-flex items-center rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground hover:bg-primary/90"
          >
            Enviar Sugestão
          </a>
        </div>
      </div>
    </div>
  );
}